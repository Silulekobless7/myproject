/*    */ import org.opencv.core.Mat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Mat
/*    */ {
/*    */   null(int $anonymous0, int $anonymous1, int $anonymous2) {
/* 76 */     super($anonymous0, $anonymous1, $anonymous2);
/*    */     
/* 78 */     put(0, 0, new double[] { -1.0D });
/* 79 */     put(0, 1, new double[] { 0.0D });
/* 80 */     put(0, 2, new double[] { 1.0D });
/* 81 */     put(1, 0, new double[] { -1.0D });
/* 82 */     put(1, 1, new double[] { 0.0D });
/* 83 */     put(1, 2, new double[] { 1.0D });
/* 84 */     put(2, 0, new double[] { -1.0D });
/* 85 */     put(2, 1, new double[] { 0.0D });
/* 86 */     put(2, 2, new double[] { 1.0D });
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\EdgeDetectors$2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */