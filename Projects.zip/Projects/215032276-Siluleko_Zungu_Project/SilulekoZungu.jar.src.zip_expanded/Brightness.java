/*    */ import java.awt.image.BufferedImage;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.highgui.Highgui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Brightness
/*    */ {
/*    */   BufferedImage image;
/*    */   
/*    */   public BufferedImage enhanceBrightness(String input, double alpha, double beta) {
/*    */     try {
/* 21 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 22 */       Mat source = Highgui.imread(input, 1);
/* 23 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 25 */       source.convertTo(destination, -1, alpha, beta);
/* 26 */       Highgui.imwrite("Brightness_" + input, destination);
/*    */       
/* 28 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 29 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */     }
/* 31 */     catch (Exception e) {
/* 32 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/* 34 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Brightness.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */