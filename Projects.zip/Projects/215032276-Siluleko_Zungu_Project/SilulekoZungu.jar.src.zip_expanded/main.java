/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class main
/*    */ {
/*    */   public static void main(String[] args) {
/* 13 */     File image = new File("fett.jpg");
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */