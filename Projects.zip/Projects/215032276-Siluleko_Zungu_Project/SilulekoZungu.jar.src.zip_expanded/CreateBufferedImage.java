/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.DataBufferByte;
/*    */ import java.io.File;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.CvType;
/*    */ import org.opencv.core.Mat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateBufferedImage
/*    */ {
/*    */   public BufferedImage Mat2BufferedImage(Mat m) {
/* 21 */     int type = 10;
/*    */     
/* 23 */     if (m.channels() > 1) {
/* 24 */       type = 5;
/*    */     }
/*    */     
/* 27 */     int bufferSize = m.channels() * m.cols() * m.rows();
/*    */     
/* 29 */     byte[] b = new byte[bufferSize];
/*    */     
/* 31 */     m.get(0, 0, b);
/*    */     
/* 33 */     BufferedImage image = new BufferedImage(m.cols(), m.rows(), type);
/*    */     
/* 35 */     byte[] targetPixels = ((DataBufferByte)image.getRaster().getDataBuffer()).getData();
/*    */     
/* 37 */     System.arraycopy(b, 0, targetPixels, 0, b.length);
/*    */     
/* 39 */     return image;
/*    */   }
/*    */ 
/*    */   
/*    */   public void displayImage(Image image) {
/* 44 */     ImageIcon icon = new ImageIcon(image);
/*    */     
/* 46 */     JFrame frame = new JFrame();
/* 47 */     frame.setLayout(new FlowLayout());
/* 48 */     frame.setSize(image.getWidth(null) + 50, image.getHeight(null) + 50);
/*    */     
/* 50 */     JLabel lbl = new JLabel();
/* 51 */     lbl.setIcon(icon);
/*    */     
/* 53 */     frame.add(lbl);
/* 54 */     frame.setVisible(true);
/* 55 */     frame.setDefaultCloseOperation(3);
/*    */   }
/*    */ 
/*    */   
/*    */   public BufferedImage createBufferedImage(File input) {
/* 60 */     BufferedImage i = null;
/*    */ 
/*    */     
/*    */     try {
/* 64 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*    */       
/* 66 */       BufferedImage image = ImageIO.read(input);
/*    */       
/* 68 */       byte[] data = ((DataBufferByte)image.getRaster().getDataBuffer()).getData();
/* 69 */       Mat mat = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
/* 70 */       mat.put(0, 0, data);
/*    */       
/* 72 */       i = Mat2BufferedImage(mat);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 80 */     catch (Exception e) {
/*    */       
/* 82 */       System.out.println("Error: " + e.getMessage());
/*    */     } 
/*    */     
/* 85 */     return i;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\CreateBufferedImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */