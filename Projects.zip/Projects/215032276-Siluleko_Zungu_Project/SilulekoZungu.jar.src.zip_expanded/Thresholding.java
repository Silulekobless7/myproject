/*    */ import java.awt.image.BufferedImage;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.highgui.Highgui;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Thresholding
/*    */ {
/*    */   String input;
/*    */   BufferedImage image;
/*    */   
/*    */   public Thresholding(String input) {
/* 21 */     this.input = input;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BufferedImage ThreshToZero() {
/*    */     try {
/* 28 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 29 */       Mat source = Highgui.imread(this.input, 1);
/* 30 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 32 */       destination = source;
/* 33 */       Imgproc.threshold(source, destination, 127.0D, 255.0D, 3);
/* 34 */       Highgui.imwrite("ThresToZero_" + this.input, destination);
/*    */       
/* 36 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 37 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */     
/*    */     }
/* 40 */     catch (Exception e) {
/*    */       
/* 42 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/*    */     
/* 45 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BufferedImage ThreshBinary() {
/*    */     try {
/* 52 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 53 */       Mat source = Highgui.imread(this.input, 1);
/* 54 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 56 */       destination = source;
/* 57 */       Imgproc.threshold(source, destination, 127.0D, 255.0D, 0);
/* 58 */       Highgui.imwrite("ThreshBinary_" + this.input, destination);
/*    */       
/* 60 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 61 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */ 
/*    */     
/*    */     }
/* 65 */     catch (Exception e) {
/*    */       
/* 67 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/*    */     
/* 70 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BufferedImage ThreshBinaryInv() {
/*    */     try {
/* 77 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 78 */       Mat source = Highgui.imread(this.input, 1);
/* 79 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 81 */       destination = source;
/* 82 */       Imgproc.threshold(source, destination, 127.0D, 255.0D, 1);
/* 83 */       Highgui.imwrite("ThreshBinInv" + this.input, destination);
/*    */       
/* 85 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 86 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */ 
/*    */     
/*    */     }
/* 90 */     catch (Exception e) {
/*    */       
/* 92 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/*    */     
/* 95 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Thresholding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */