/*    */ import java.awt.Image;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ public class BrowseImage {
/* 12 */   private String imagePath = "";
/* 13 */   private String name = "";
/* 14 */   private String rep = "\\ \" \\";
/* 15 */   private String fileName = "";
/*    */ 
/*    */ 
/*    */   
/*    */   public String findPath(String path) {
/*    */     try {
/* 21 */       path = path.replace(this.rep.substring(this.rep.length() - 1), "/");
/*    */       
/* 23 */       this.fileName = path.substring(path.lastIndexOf("/") + 1);
/* 24 */       System.out.println(this.fileName);
/* 25 */       File file_1 = new File(path);
/*    */       
/* 27 */       this.name = this.fileName;
/* 28 */       File file_2 = new File(this.name);
/*    */       
/* 30 */       if (!file_2.exists())
/*    */       {
/* 32 */         InputStream in = new FileInputStream(file_1);
/*    */         
/* 34 */         OutputStream out = new FileOutputStream(file_2);
/*    */         
/* 36 */         byte[] buf = new byte[1024];
/*    */         
/*    */         int len;
/* 39 */         while ((len = in.read(buf)) > 0)
/*    */         {
/* 41 */           out.write(buf, 0, len);
/*    */         }
/*    */         
/* 44 */         in.close();
/* 45 */         out.close();
/*    */         
/* 47 */         if (file_2.exists())
/*    */         {
/* 49 */           System.out.println("Successful");
/*    */         
/*    */         }
/*    */         else
/*    */         {
/* 54 */           System.out.println("Unsuccessful");
/*    */         }
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 60 */     catch (Exception e) {
/*    */       
/* 62 */       JOptionPane.showMessageDialog(null, e.toString());
/*    */     } 
/* 64 */     return this.fileName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFileName() {
/* 69 */     return this.fileName;
/*    */   }
/*    */ 
/*    */   
/*    */   public Image browseImage() {
/* 74 */     JFileChooser chooser = new JFileChooser();
/* 75 */     int option = chooser.showOpenDialog(null);
/* 76 */     Image image = null;
/* 77 */     ImageIcon newIcon = null;
/*    */     
/* 79 */     String path = "";
/*    */     
/* 81 */     if (option == 0) {
/*    */       
/* 83 */       path = chooser.getSelectedFile().getPath();
/* 84 */       String nameFile = findPath(path);
/* 85 */       path = path.replace("/", "\\");
/* 86 */       int psn = path.lastIndexOf('\\');
/* 87 */       String pic = path.substring(psn + 1);
/*    */       
/* 89 */       System.out.println(path);
/* 90 */       ImageIcon icon = new ImageIcon(path);
/* 91 */       image = icon.getImage();
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 96 */     findPath(path);
/*    */     
/* 98 */     return image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\BrowseImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */