/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JLabel;
/*     */ import org.opencv.core.Core;
/*     */ import org.opencv.core.Mat;
/*     */ import org.opencv.core.MatOfPoint;
/*     */ import org.opencv.highgui.Highgui;
/*     */ import org.opencv.imgproc.Imgproc;
/*     */ import org.opencv.imgproc.Moments;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements ActionListener
/*     */ {
/*     */   public void actionPerformed(ActionEvent arg0) {
/* 570 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 571 */     Mat source = Highgui.imread("old10fronteq.jpg", 0);
/* 572 */     Mat fin = new Mat(source.rows(), source.cols(), source.type());
/* 573 */     Imgproc.equalizeHist(source, fin);
/* 574 */     List<MatOfPoint> contours = new ArrayList<>();
/* 575 */     Imgproc.findContours(source, contours, new Mat(), 1, 2);
/* 576 */     Moments mom = new Moments();
/* 577 */     mom = Imgproc.moments((Mat)contours.get(0), false);
/* 578 */     Mat oldTenFrontHu = new Mat();
/* 579 */     Imgproc.HuMoments(mom, oldTenFrontHu);
/*     */ 
/*     */     
/* 582 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 583 */     Mat sourcetb = Highgui.imread("old10backeq.jpg", 0);
/* 584 */     Mat fintb = new Mat(sourcetb.rows(), sourcetb.cols(), sourcetb.type());
/* 585 */     Imgproc.equalizeHist(sourcetb, fintb);
/* 586 */     List<MatOfPoint> contourstb = new ArrayList<>();
/* 587 */     Imgproc.findContours(sourcetb, contourstb, new Mat(), 1, 2);
/* 588 */     Moments momtb = new Moments();
/* 589 */     momtb = Imgproc.moments((Mat)contourstb.get(0), false);
/* 590 */     Mat oldTenBackHu = new Mat();
/* 591 */     Imgproc.HuMoments(momtb, oldTenBackHu);
/*     */ 
/*     */     
/* 594 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 595 */     Mat sourcenewten = Highgui.imread("new10fronteq.jpg", 0);
/* 596 */     Mat finnew10 = new Mat(sourcenewten.rows(), sourcenewten.cols(), sourcenewten.type());
/* 597 */     Imgproc.equalizeHist(sourcenewten, finnew10);
/* 598 */     List<MatOfPoint> contoursnew10 = new ArrayList<>();
/* 599 */     Imgproc.findContours(sourcenewten, contoursnew10, new Mat(), 1, 2);
/* 600 */     Moments momn10 = new Moments();
/* 601 */     momn10 = Imgproc.moments((Mat)contoursnew10.get(0), false);
/* 602 */     Mat newTenFrontHu = new Mat();
/* 603 */     Imgproc.HuMoments(momn10, newTenFrontHu);
/*     */ 
/*     */     
/* 606 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 607 */     Mat sn10b = Highgui.imread("new10backeq.jpg", 0);
/* 608 */     Mat fn10b = new Mat(sn10b.rows(), sn10b.cols(), sn10b.type());
/* 609 */     Imgproc.equalizeHist(sn10b, fn10b);
/* 610 */     List<MatOfPoint> cn10b = new ArrayList<>();
/* 611 */     Imgproc.findContours(sn10b, cn10b, new Mat(), 1, 2);
/* 612 */     Moments mn10b = new Moments();
/* 613 */     mn10b = Imgproc.moments((Mat)cn10b.get(0), false);
/* 614 */     Mat newTenBackHu = new Mat();
/* 615 */     Imgproc.HuMoments(mn10b, newTenBackHu);
/*     */ 
/*     */     
/* 618 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 619 */     Mat so20f = Highgui.imread("old20fronteq.jpg", 0);
/* 620 */     Mat f020f = new Mat(so20f.rows(), so20f.cols(), so20f.type());
/* 621 */     Imgproc.equalizeHist(so20f, f020f);
/* 622 */     List<MatOfPoint> co20f = new ArrayList<>();
/* 623 */     Imgproc.findContours(so20f, co20f, new Mat(), 1, 2);
/* 624 */     Moments mo20f = new Moments();
/* 625 */     mo20f = Imgproc.moments((Mat)co20f.get(0), false);
/* 626 */     Mat oldTwentyFrontHu = new Mat();
/* 627 */     Imgproc.HuMoments(mo20f, oldTwentyFrontHu);
/*     */ 
/*     */     
/* 630 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 631 */     Mat so20b = Highgui.imread("old20backeq.jpg", 0);
/* 632 */     Mat f020b = new Mat(so20b.rows(), so20b.cols(), so20b.type());
/* 633 */     Imgproc.equalizeHist(so20b, f020b);
/* 634 */     List<MatOfPoint> co20b = new ArrayList<>();
/* 635 */     Imgproc.findContours(so20b, co20b, new Mat(), 1, 2);
/* 636 */     Moments mo20b = new Moments();
/* 637 */     mo20b = Imgproc.moments((Mat)co20f.get(0), false);
/* 638 */     Mat oldTwentyBackHu = new Mat();
/* 639 */     Imgproc.HuMoments(mo20b, oldTwentyBackHu);
/*     */ 
/*     */     
/* 642 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 643 */     Mat sn20f = Highgui.imread("new20fronteq.jpg", 0);
/* 644 */     Mat fn20f = new Mat(sn20f.rows(), sn20f.cols(), sn20f.type());
/* 645 */     Imgproc.equalizeHist(sn20f, fn20f);
/* 646 */     List<MatOfPoint> cn20f = new ArrayList<>();
/* 647 */     Imgproc.findContours(sn20f, cn20f, new Mat(), 1, 2);
/* 648 */     Moments mn20f = new Moments();
/* 649 */     mn20f = Imgproc.moments((Mat)cn20f.get(0), false);
/* 650 */     Mat newTwentyFrontHu = new Mat();
/* 651 */     Imgproc.HuMoments(mn20f, newTwentyFrontHu);
/*     */ 
/*     */     
/* 654 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 655 */     Mat sn20b = Highgui.imread("new20backeq.jpg", 0);
/* 656 */     Mat fn20b = new Mat(sn20b.rows(), sn20b.cols(), sn20b.type());
/* 657 */     Imgproc.equalizeHist(sn20b, fn20b);
/* 658 */     List<MatOfPoint> cn20b = new ArrayList<>();
/* 659 */     Imgproc.findContours(sn20b, cn20b, new Mat(), 1, 2);
/* 660 */     Moments mn20b = new Moments();
/* 661 */     mn20b = Imgproc.moments((Mat)cn20b.get(0), false);
/* 662 */     Mat newTwentyBackHu = new Mat();
/* 663 */     Imgproc.HuMoments(mn20b, newTwentyBackHu);
/*     */ 
/*     */     
/* 666 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 667 */     Mat so50f = Highgui.imread("old50fronteq.jpg", 0);
/* 668 */     Mat f050f = new Mat(so50f.rows(), so50f.cols(), so50f.type());
/* 669 */     Imgproc.equalizeHist(so50f, f050f);
/* 670 */     List<MatOfPoint> co50f = new ArrayList<>();
/* 671 */     Imgproc.findContours(so50f, co50f, new Mat(), 1, 2);
/* 672 */     Moments mo50f = new Moments();
/* 673 */     mo50f = Imgproc.moments((Mat)co50f.get(0), false);
/* 674 */     Mat oldFiftyFrontHu = new Mat();
/* 675 */     Imgproc.HuMoments(mo50f, oldFiftyFrontHu);
/*     */ 
/*     */     
/* 678 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 679 */     Mat so50b = Highgui.imread("old50backeq.jpg", 0);
/* 680 */     Mat f050b = new Mat(so50b.rows(), so50b.cols(), so50b.type());
/* 681 */     Imgproc.equalizeHist(so50b, f050b);
/* 682 */     List<MatOfPoint> co50b = new ArrayList<>();
/* 683 */     Imgproc.findContours(so50b, co50b, new Mat(), 1, 2);
/* 684 */     Moments mo50b = new Moments();
/* 685 */     mo50b = Imgproc.moments((Mat)co50b.get(0), false);
/* 686 */     Mat oldFiftyBackHu = new Mat();
/* 687 */     Imgproc.HuMoments(mo50b, oldFiftyBackHu);
/*     */ 
/*     */     
/* 690 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 691 */     Mat sn50f = Highgui.imread("new50fronteq.jpg", 0);
/* 692 */     Mat fn50f = new Mat(sn50f.rows(), sn50f.cols(), sn50f.type());
/* 693 */     Imgproc.equalizeHist(sn50f, fn50f);
/* 694 */     List<MatOfPoint> cn50f = new ArrayList<>();
/* 695 */     Imgproc.findContours(sn50f, cn50f, new Mat(), 1, 2);
/* 696 */     Moments mn50f = new Moments();
/* 697 */     mn50f = Imgproc.moments((Mat)cn50f.get(0), false);
/* 698 */     Mat newFiftyFrontHu = new Mat();
/* 699 */     Imgproc.HuMoments(mn50f, newFiftyFrontHu);
/*     */ 
/*     */     
/* 702 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 703 */     Mat sn50b = Highgui.imread("new50backeq.jpg", 0);
/* 704 */     Mat fn50b = new Mat(sn50b.rows(), sn50b.cols(), sn50b.type());
/* 705 */     Imgproc.equalizeHist(sn50b, fn50b);
/* 706 */     List<MatOfPoint> cn50b = new ArrayList<>();
/* 707 */     Imgproc.findContours(sn50b, cn50b, new Mat(), 1, 2);
/* 708 */     Moments mn50b = new Moments();
/* 709 */     mn50b = Imgproc.moments((Mat)cn50b.get(0), false);
/* 710 */     Mat newFiftyBackHu = new Mat();
/* 711 */     Imgproc.HuMoments(mn50b, newFiftyBackHu);
/*     */ 
/*     */     
/* 714 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 715 */     Mat so100f = Highgui.imread("old100fronteq.jpg", 0);
/* 716 */     Mat f0100f = new Mat(so100f.rows(), so100f.cols(), so100f.type());
/* 717 */     Imgproc.equalizeHist(so100f, f0100f);
/* 718 */     List<MatOfPoint> co100f = new ArrayList<>();
/* 719 */     Imgproc.findContours(so100f, co100f, new Mat(), 1, 2);
/* 720 */     Moments mo100f = new Moments();
/* 721 */     mo100f = Imgproc.moments((Mat)co100f.get(0), false);
/* 722 */     Mat oldOneHFrontHu = new Mat();
/* 723 */     Imgproc.HuMoments(mo100f, oldOneHFrontHu);
/*     */ 
/*     */     
/* 726 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 727 */     Mat so100b = Highgui.imread("old100backeq.jpg", 0);
/* 728 */     Mat f0100b = new Mat(so100b.rows(), so100b.cols(), so100b.type());
/* 729 */     Imgproc.equalizeHist(so100b, f0100b);
/* 730 */     List<MatOfPoint> co100b = new ArrayList<>();
/* 731 */     Imgproc.findContours(so100b, co100b, new Mat(), 1, 2);
/* 732 */     Moments mo100b = new Moments();
/* 733 */     mo100b = Imgproc.moments((Mat)co100b.get(0), false);
/* 734 */     Mat oldOneHBackHu = new Mat();
/* 735 */     Imgproc.HuMoments(mo100b, oldOneHBackHu);
/*     */ 
/*     */     
/* 738 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 739 */     Mat sn100f = Highgui.imread("new100fronteq.jpg", 0);
/* 740 */     Mat fn100f = new Mat(sn100f.rows(), sn100f.cols(), sn100f.type());
/* 741 */     Imgproc.equalizeHist(sn100f, fn100f);
/* 742 */     List<MatOfPoint> cn100f = new ArrayList<>();
/* 743 */     Imgproc.findContours(sn100f, cn100f, new Mat(), 1, 2);
/* 744 */     Moments mn100f = new Moments();
/* 745 */     mn100f = Imgproc.moments((Mat)cn100f.get(0), false);
/* 746 */     Mat newOneHFrontHu = new Mat();
/* 747 */     Imgproc.HuMoments(mn100f, newOneHFrontHu);
/*     */ 
/*     */     
/* 750 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 751 */     Mat sn100b = Highgui.imread("new100backeq.jpg", 0);
/* 752 */     Mat fn100b = new Mat(sn100b.rows(), sn100b.cols(), sn100b.type());
/* 753 */     Imgproc.equalizeHist(sn100b, fn100b);
/* 754 */     List<MatOfPoint> cn100b = new ArrayList<>();
/* 755 */     Imgproc.findContours(sn100b, cn100b, new Mat(), 1, 2);
/* 756 */     Moments mn100b = new Moments();
/* 757 */     mn100b = Imgproc.moments((Mat)cn100b.get(0), false);
/* 758 */     Mat newOneHBackHu = new Mat();
/* 759 */     Imgproc.HuMoments(mn100b, newOneHBackHu);
/*     */ 
/*     */     
/* 762 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 763 */     Mat so200f = Highgui.imread("old200fronteq.jpg", 0);
/* 764 */     Mat f0200f = new Mat(so200f.rows(), so200f.cols(), so200f.type());
/* 765 */     Imgproc.equalizeHist(so200f, f0200f);
/* 766 */     List<MatOfPoint> co200f = new ArrayList<>();
/* 767 */     Imgproc.findContours(so200f, co200f, new Mat(), 1, 2);
/* 768 */     Moments mo200f = new Moments();
/* 769 */     mo200f = Imgproc.moments((Mat)co100f.get(0), false);
/* 770 */     Mat oldTwoHFrontHu = new Mat();
/* 771 */     Imgproc.HuMoments(mo200f, oldTwoHFrontHu);
/*     */ 
/*     */     
/* 774 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 775 */     Mat so200b = Highgui.imread("old200backeq.jpg", 0);
/* 776 */     Mat f0200b = new Mat(so200b.rows(), so200b.cols(), so200b.type());
/* 777 */     Imgproc.equalizeHist(so200b, f0200b);
/* 778 */     List<MatOfPoint> co200b = new ArrayList<>();
/* 779 */     Imgproc.findContours(so200b, co200b, new Mat(), 1, 2);
/* 780 */     Moments mo200b = new Moments();
/* 781 */     mo200b = Imgproc.moments((Mat)co200b.get(0), false);
/* 782 */     Mat oldTwoHBackHu = new Mat();
/* 783 */     Imgproc.HuMoments(mo200b, oldTwoHBackHu);
/*     */ 
/*     */     
/* 786 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 787 */     Mat sn200f = Highgui.imread("new200fronteq.jpg", 0);
/* 788 */     Mat fn200f = new Mat(sn200f.rows(), sn200f.cols(), sn200f.type());
/* 789 */     Imgproc.equalizeHist(sn200f, fn200f);
/* 790 */     List<MatOfPoint> cn200f = new ArrayList<>();
/* 791 */     Imgproc.findContours(sn200f, cn200f, new Mat(), 1, 2);
/* 792 */     Moments mn200f = new Moments();
/* 793 */     mn200f = Imgproc.moments((Mat)cn200f.get(0), false);
/* 794 */     Mat newTwoHFrontHu = new Mat();
/* 795 */     Imgproc.HuMoments(mn200f, newTwoHFrontHu);
/*     */ 
/*     */     
/* 798 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 799 */     Mat sn200b = Highgui.imread("new200backeq.jpg", 0);
/* 800 */     Mat fn200b = new Mat(sn200b.rows(), sn200b.cols(), sn200b.type());
/* 801 */     Imgproc.equalizeHist(sn200b, fn200b);
/* 802 */     List<MatOfPoint> cn200b = new ArrayList<>();
/* 803 */     Imgproc.findContours(sn200b, cn200b, new Mat(), 1, 2);
/* 804 */     Moments mn200b = new Moments();
/* 805 */     mn200b = Imgproc.moments((Mat)cn200b.get(0), false);
/* 806 */     Mat newTwoHBackHu = new Mat();
/* 807 */     Imgproc.HuMoments(mn200b, newTwoHBackHu);
/*     */ 
/*     */     
/* 810 */     GrayScale_2 gs = new GrayScale_2();
/* 811 */     File in = new File(BankNotesRecognitionSystem.this.restoreFile);
/* 812 */     System.out.println("Original File -> " + BankNotesRecognitionSystem.this.restoreFile);
/* 813 */     CreateBufferedImage cv = new CreateBufferedImage();
/*     */     
/* 815 */     BufferedImage g = cv.createBufferedImage(new File(BankNotesRecognitionSystem.this.restoreFile));
/*     */     try {
/* 817 */       Image image = gs.greyImage(g);
/* 818 */     } catch (Exception exception) {}
/* 819 */     HistogramEqualisation_2 sh = new HistogramEqualisation_2();
/* 820 */     Mat shim = sh.histogram("grayscale.jpg");
/*     */     
/* 822 */     Image x7 = BankNotesRecognitionSystem.x.Mat2BufferedImage(shim);
/*     */     
/* 824 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 825 */     Mat st = Highgui.imread("equalisation.jpg", 0);
/* 826 */     Mat ft = new Mat(st.rows(), st.cols(), st.type());
/* 827 */     Imgproc.equalizeHist(st, ft);
/* 828 */     List<MatOfPoint> ct = new ArrayList<>();
/* 829 */     Imgproc.findContours(st, ct, new Mat(), 1, 2);
/* 830 */     Moments mt = new Moments();
/* 831 */     mt = Imgproc.moments((Mat)ct.get(0), false);
/* 832 */     Mat HuTest = new Mat();
/* 833 */     Imgproc.HuMoments(mt, HuTest);
/*     */ 
/*     */     
/* 836 */     for (int k = 0; k < 7; k++) {
/* 837 */       if (HuTest.get(k, 0)[0] == oldTenFrontHu.get(k, 0)[0]) {
/* 838 */         lblResult.setText("OLD TEN RAND");
/*     */       
/*     */       }
/* 841 */       else if (HuTest.get(k, 0)[0] == oldTenBackHu.get(k, 0)[0]) {
/* 842 */         lblResult.setText("OLD TEN RAND");
/*     */       
/*     */       }
/* 845 */       else if (HuTest.get(k, 0)[0] == newTenFrontHu.get(k, 0)[0]) {
/* 846 */         lblResult.setText("NEW TEN RAND");
/*     */       
/*     */       }
/* 849 */       else if (HuTest.get(k, 0)[0] == newTenBackHu.get(k, 0)[0]) {
/* 850 */         lblResult.setText("NEW TEN RAND");
/*     */       
/*     */       }
/* 853 */       else if (HuTest.get(k, 0)[0] == oldTwentyFrontHu.get(k, 0)[0]) {
/* 854 */         lblResult.setText("OLD TWENTY RAND");
/*     */       
/*     */       }
/* 857 */       else if (HuTest.get(k, 0)[0] == oldTwentyBackHu.get(k, 0)[0]) {
/* 858 */         lblResult.setText("OLD TWENTY RAND");
/*     */       
/*     */       }
/* 861 */       else if (HuTest.get(k, 0)[0] == newTwentyFrontHu.get(k, 0)[0]) {
/* 862 */         lblResult.setText("NEW TWENTY RAND");
/*     */       
/*     */       }
/* 865 */       else if (HuTest.get(k, 0)[0] == newTwentyBackHu.get(k, 0)[0]) {
/* 866 */         lblResult.setText("NEW TWENTY RAND");
/*     */       
/*     */       }
/* 869 */       else if (HuTest.get(k, 0)[0] == oldFiftyFrontHu.get(k, 0)[0]) {
/* 870 */         lblResult.setText("OLD FIFTY RAND");
/*     */       
/*     */       }
/* 873 */       else if (HuTest.get(k, 0)[0] == oldFiftyBackHu.get(k, 0)[0]) {
/* 874 */         lblResult.setText("OLD FIFTY RAND");
/*     */       
/*     */       }
/* 877 */       else if (HuTest.get(k, 0)[0] == newFiftyFrontHu.get(k, 0)[0]) {
/* 878 */         lblResult.setText("NEW FIFTY RAND");
/*     */       
/*     */       }
/* 881 */       else if (HuTest.get(k, 0)[0] == newFiftyBackHu.get(k, 0)[0]) {
/* 882 */         lblResult.setText("NEW FIFTY RAND");
/*     */       
/*     */       }
/* 885 */       else if (HuTest.get(k, 0)[0] == oldOneHFrontHu.get(k, 0)[0]) {
/* 886 */         lblResult.setText("OLD ONE HUNDRED RAND");
/*     */       
/*     */       }
/* 889 */       else if (HuTest.get(k, 0)[0] == oldOneHBackHu.get(k, 0)[0]) {
/* 890 */         lblResult.setText("OLD ONE HUNDRED RAND");
/*     */       
/*     */       }
/* 893 */       else if (HuTest.get(k, 0)[0] == newOneHFrontHu.get(k, 0)[0]) {
/* 894 */         lblResult.setText("NEW ONE HUNDRED RAND");
/*     */       
/*     */       }
/* 897 */       else if (HuTest.get(k, 0)[0] == newOneHBackHu.get(k, 0)[0]) {
/* 898 */         lblResult.setText("NEW ONE HUNDRED RAND");
/*     */       
/*     */       }
/* 901 */       else if (HuTest.get(k, 0)[0] == oldTwoHFrontHu.get(k, 0)[0]) {
/* 902 */         lblResult.setText("OLD TWO HUNDRED RAND");
/*     */       
/*     */       }
/* 905 */       else if (HuTest.get(k, 0)[0] == oldTwoHBackHu.get(k, 0)[0]) {
/* 906 */         lblResult.setText("OLD TWO HUNDRED RAND");
/*     */       
/*     */       }
/* 909 */       else if (HuTest.get(k, 0)[0] == newTwoHFrontHu.get(k, 0)[0]) {
/* 910 */         lblResult.setText("NEW TWO HUNDRED RAND");
/*     */       
/*     */       }
/* 913 */       else if (HuTest.get(k, 0)[0] == newTwoHBackHu.get(k, 0)[0]) {
/* 914 */         lblResult.setText("NEW TWO HUNDRED RAND");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\BankNotesRecognitionSystem$16.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */