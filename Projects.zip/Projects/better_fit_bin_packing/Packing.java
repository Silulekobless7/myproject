package better_fit_bin_packing;

import java.util.ArrayList;
import java.util.List;

public class Packing
{

    private int binCapacity;
    private int[] items;

    public Packing(int BinCapacity, int[] items)
    {
        this.binCapacity = BinCapacity;
        this.items = items;
    }

    public int getBinCapacity()
    {
        return binCapacity;
    }

    public int[] getItems()
    {
        return items;
    }

    public void setBinCapacity(int binCapacity)
    {
        this.binCapacity = binCapacity;
    }

    public void setItems(int[] items)
    {
        this.items = items;
    }

    List<List<Integer>> bins = new ArrayList<List<Integer>>();

    public void pack()
    {

        for (int item : items)
        {
            betterFit(item);
        }
    }

    //Calculates the total of the items in the bin (Checked)
    public int calculateBinSize(List<Integer> binItems)
    {
        int totalValue = 0;
        for (Integer binItem : binItems)
        {
            totalValue += binItem;
        }
        return totalValue;
    }

    public void betterFit(final int nextObject)
    {
        int theObject = nextObject;


        for (int i = 0; i < bins.size(); i++)
        {
            List<Integer> bin = bins.get(i);

            //Put this packet in this bin if this packet is the better fit
            int index = isBetterFit(bin, theObject);
            if (index != -1)
            {
                int tmp = theObject;
                theObject = bin.get(index);
                bin.remove(index);
                bin.add(tmp);
            }
            //return the object to be removed
        }

        bestFit(theObject);

    }

    /**
     * this part inserts the first item on the list to be packed or
     * the last replaced object is then packed with the best-fit heuristic (Checked)
     **/
    public void bestFit(int newObject)
    {
        int itemAdded = 0;

        if (bins.size() > 0)
        {
            for (int i = 0; i < bins.size(); i++)
            {
                int newBinCap = calculateBinSize(bins.get(i)) + newObject;
                if (newBinCap <= binCapacity)
                {
                    bins.get(i).add(newObject);
                    itemAdded = 1;

                    break;
                }
            }
        }

        if (itemAdded == 0)
        {
            List<Integer> newBin = new ArrayList<Integer>();
            if (newObject < binCapacity)
            {
                newBin.add(newObject);
                bins.add(newBin);
                //System.out.println("Item added 2nd if, the Bin number is : " + Bins.size());

            }
            else
            {
                System.out.println("Error !, Item size greater than bigger bin size");
            }
        }
    }


    /**
     * Checks if this packet fits better in this bin
     *
     * @param bin    the bin to check
     * @param packet the packet to fit in the bin
     * @return the index of the packet to be removed to fit the
     * given packet, return -1 if the packet is not a better fit
     * in this bin
     */
    private int isBetterFit(final List<Integer> bin, final int packet)
    {
        int binSize = calculateBinSize(bin);

        for (int index = 0; index < bin.size(); index++)
        {
            int newSize = 0;

            for (int index2 = 0; index2 < bin.size(); index2++)
            {
                if (index == index2)
                {
                    newSize += packet;
                }
                else
                {
                    newSize += bin.get(index2);
                }
            }

            if (binSize < newSize) return index;
        }

        return -1;
    }

    public List<List<Integer>> getBins()
    {
        return bins;
    }

    public int getTotalBins()
    {
        return bins.size();
    }

    /**In this version i didn't include the wastage*/
    public void printPackedInfo()
    {
        System.out.println("Number of bins is: " + bins.size());
        for (int i = 0; i < bins.size(); i++)
        {
            System.out.println("Items in Bin " + (i + 1) + ": " + bins.get(i).toString());
        }

    }

}
