package better_fit_bin_packing;

import java.awt.*;
import java.io.File;
import java.util.Scanner;

public class BinPackingMain
{
    public static void main(String[] args)
    {
        int capacity = 0;
        int numItems = 0;
        int[] items = null;
        int counter = 0;
        int swarmSize = 0;
        int noCycles = 0;
        Scanner scan = new Scanner(System.in);
        try
        {
            File file = new File("resources/N4C3W4_R.BPP");
            Scanner sc = new Scanner(file);
            numItems = sc.nextInt();
            capacity = sc.nextInt();
            items = new int[numItems];

            while (sc.hasNextInt())
            {
                int i = sc.nextInt();
                items[counter] = i;
                counter++;

            }
            sc.close();


        }
        catch (Exception e)
        {
            System.out.println("File not available");
        }
        
        Packing p = new Packing(capacity, items);
        p.pack();
        p.printPackedInfo();
    }
}
