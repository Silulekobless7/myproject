/*      */ import java.awt.Color;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Font;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.DataBufferByte;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JSlider;
/*      */ import javax.swing.LayoutStyle;
/*      */ import javax.swing.border.BevelBorder;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.border.TitledBorder;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import org.opencv.core.Core;
/*      */ import org.opencv.core.Mat;
/*      */ import org.opencv.core.MatOfPoint;
/*      */ import org.opencv.highgui.Highgui;
/*      */ import org.opencv.imgproc.Imgproc;
/*      */ import org.opencv.imgproc.Moments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BankNotesRecognitionSystem
/*      */   extends JFrame
/*      */ {
/*      */   private JPanel contentPane;
/*   80 */   CreateBufferedImage cbi = new CreateBufferedImage(); Image image;
/*      */   Image restoreImage;
/*      */   Image processedImage;
/*   83 */   private final Action action = new SwingAction(); String fileName; String processedFile; String restoreFile;
/*   84 */   private final ButtonGroup buttonGroup = new ButtonGroup();
/*   85 */   private final ButtonGroup buttonGroup_1 = new ButtonGroup();
/*   86 */   private final ButtonGroup buttonGroup_2 = new ButtonGroup();
/*   87 */   private final ButtonGroup buttonGroup_3 = new ButtonGroup();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/*   93 */     EventQueue.invokeLater(new Runnable() {
/*      */           public void run() {
/*      */             try {
/*   96 */               BankNotesRecognitionSystem frame = new BankNotesRecognitionSystem();
/*   97 */               frame.setVisible(true);
/*   98 */             } catch (Exception e) {
/*   99 */               e.printStackTrace();
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   static BankNotesRecognitionSystem x = new BankNotesRecognitionSystem();
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage Mat2BufferedImage(Mat m) {
/*  113 */     int type = 10;
/*  114 */     if (m.channels() > 1) {
/*  115 */       type = 5;
/*      */     }
/*  117 */     int bufferSize = m.channels() * m.cols() * m.rows();
/*  118 */     byte[] b = new byte[bufferSize];
/*  119 */     m.get(0, 0, b);
/*  120 */     BufferedImage image = new BufferedImage(m.cols(), m.rows(), type);
/*  121 */     byte[] targetPixels = ((DataBufferByte)image.getRaster().getDataBuffer()).getData();
/*  122 */     System.arraycopy(b, 0, targetPixels, 0, b.length);
/*  123 */     return image;
/*      */   }
/*      */   
/*      */   public BankNotesRecognitionSystem() {
/*  127 */     setTitle("215032276-Siluleko Zungu");
/*  128 */     setDefaultCloseOperation(3);
/*  129 */     setBounds(30, 30, 900, 600);
/*  130 */     this.contentPane = new JPanel();
/*  131 */     this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/*  132 */     setContentPane(this.contentPane);
/*  133 */     this.contentPane.setLayout((LayoutManager)null);
/*      */     
/*  135 */     JPanel panel = new JPanel();
/*  136 */     panel.setBounds(0, 0, 884, 456);
/*  137 */     this.contentPane.add(panel);
/*  138 */     panel.setLayout((LayoutManager)null);
/*      */     
/*  140 */     final JLabel pictureLabel = new JLabel("Original Image");
/*  141 */     pictureLabel.setHorizontalAlignment(0);
/*  142 */     pictureLabel.setBounds(10, 45, 309, 175);
/*  143 */     panel.add(pictureLabel);
/*      */     
/*  145 */     JButton btnOpenImage = new JButton("Open Image");
/*  146 */     btnOpenImage.setToolTipText("Browse your computer for a test image");
/*  147 */     btnOpenImage.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0) {
/*  150 */             BrowseImage imageBrowser = new BrowseImage();
/*  151 */             BankNotesRecognitionSystem.this.image = imageBrowser.browseImage();
/*  152 */             BankNotesRecognitionSystem.this.restoreImage = BankNotesRecognitionSystem.this.image;
/*      */             
/*  154 */             BankNotesRecognitionSystem.this.fileName = imageBrowser.getFileName();
/*  155 */             BankNotesRecognitionSystem.this.restoreFile = BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  157 */             Image newImage = BankNotesRecognitionSystem.this.image.getScaledInstance(350, 150, 4);
/*  158 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  159 */             pictureLabel.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/*  163 */     btnOpenImage.setBounds(105, 11, 113, 23);
/*  164 */     panel.add(btnOpenImage);
/*      */     
/*  166 */     final JLabel lblProcessedImage = new JLabel("Processed Image");
/*  167 */     lblProcessedImage.setHorizontalAlignment(0);
/*  168 */     lblProcessedImage.setBounds(10, 265, 309, 175);
/*  169 */     panel.add(lblProcessedImage);
/*      */     
/*  171 */     JButton btnAcceptImage = new JButton("Accept Image");
/*  172 */     btnAcceptImage.setToolTipText("Accept the updated image");
/*  173 */     btnAcceptImage.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0) {
/*  176 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  177 */             BankNotesRecognitionSystem.this.fileName = BankNotesRecognitionSystem.this.processedFile;
/*      */             
/*  179 */             Image newImage = BankNotesRecognitionSystem.this.image.getScaledInstance(350, 150, 4);
/*  180 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  181 */             pictureLabel.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/*  185 */     btnAcceptImage.setBounds(10, 231, 134, 23);
/*  186 */     panel.add(btnAcceptImage);
/*      */     
/*  188 */     JPanel ImagePreprocessing = new JPanel();
/*  189 */     ImagePreprocessing.setBorder(new TitledBorder(new BevelBorder(1, null, null, null, null), "Preprocessing", 2, 2, null, new Color(0, 0, 0)));
/*  190 */     ImagePreprocessing.setBounds(329, 15, 263, 247);
/*  191 */     panel.add(ImagePreprocessing);
/*      */     
/*  193 */     JLabel label = new JLabel("");
/*      */     
/*  195 */     final JLabel lblAlpha = new JLabel("Alpha");
/*      */     
/*  197 */     final JLabel lblBeta = new JLabel("Beta");
/*      */     
/*  199 */     final JSlider alphaSlider = new JSlider();
/*  200 */     alphaSlider.addChangeListener(new ChangeListener() {
/*      */           public void stateChanged(ChangeEvent arg0) {
/*  202 */             lblAlpha.setText("Alpha : " + alphaSlider.getValue());
/*      */           }
/*      */         });
/*  205 */     alphaSlider.setValue(2);
/*  206 */     alphaSlider.setToolTipText("Choose alpha value");
/*  207 */     alphaSlider.setPaintTicks(true);
/*  208 */     alphaSlider.setMinimum(1);
/*  209 */     alphaSlider.setMaximum(10);
/*      */     
/*  211 */     final JSlider betaSlider = new JSlider();
/*  212 */     betaSlider.addChangeListener(new ChangeListener()
/*      */         {
/*      */           public void stateChanged(ChangeEvent arg0) {
/*  215 */             lblBeta.setText("Beta : " + betaSlider.getValue());
/*      */           }
/*      */         });
/*  218 */     betaSlider.setMinimum(1);
/*  219 */     betaSlider.setToolTipText("Choose beta value");
/*  220 */     betaSlider.setPaintTicks(true);
/*      */     
/*  222 */     JRadioButton rdbtnNewRadioButton = new JRadioButton("Brightness");
/*  223 */     rdbtnNewRadioButton.setToolTipText("Enhance image brightness");
/*  224 */     rdbtnNewRadioButton.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  228 */             Brightness b = new Brightness();
/*      */             
/*  230 */             BufferedImage brightnessImage = b.enhanceBrightness(BankNotesRecognitionSystem.this.fileName, alphaSlider.getValue(), betaSlider.getValue());
/*      */             
/*  232 */             Image newImage = brightnessImage.getScaledInstance(350, 150, 4);
/*  233 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  234 */             lblProcessedImage.setIcon(newIcon);
/*      */             
/*  236 */             BankNotesRecognitionSystem.this.processedImage = brightnessImage;
/*  237 */             BankNotesRecognitionSystem.this.processedFile = "Brightness_" + BankNotesRecognitionSystem.this.fileName;
/*  238 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*      */           }
/*      */         });
/*      */     
/*  242 */     this.buttonGroup.add(rdbtnNewRadioButton);
/*      */     
/*  244 */     JRadioButton rdbtnGrayscale = new JRadioButton("Grayscale");
/*  245 */     rdbtnGrayscale.setToolTipText("Convert image to grayscale");
/*  246 */     this.buttonGroup.add(rdbtnGrayscale);
/*  247 */     rdbtnGrayscale.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0) {
/*  250 */             GrayScale gs = new GrayScale();
/*      */             
/*  252 */             File input = new File(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  254 */             Image gsImage = gs.grayscale(input);
/*      */             
/*  256 */             BankNotesRecognitionSystem.this.processedImage = gsImage;
/*  257 */             BankNotesRecognitionSystem.this.processedFile = "Grayscale_" + BankNotesRecognitionSystem.this.fileName;
/*  258 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*      */             
/*  260 */             Image newImage = gsImage.getScaledInstance(350, 150, 4);
/*  261 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  262 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/*  266 */     JRadioButton rdbtnHistogramEqualisation = new JRadioButton("Histogram Equalisation");
/*  267 */     this.buttonGroup.add(rdbtnHistogramEqualisation);
/*  268 */     rdbtnHistogramEqualisation.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  272 */             HistogramEqualisation he = new HistogramEqualisation();
/*      */             
/*  274 */             BufferedImage equaliseImage = he.equaliseHistogram(BankNotesRecognitionSystem.this.fileName);
/*  275 */             BankNotesRecognitionSystem.this.processedImage = equaliseImage;
/*  276 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  277 */             BankNotesRecognitionSystem.this.processedFile = "Histogram_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  279 */             Image newImage = equaliseImage.getScaledInstance(350, 150, 4);
/*  280 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  281 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  284 */     rdbtnHistogramEqualisation.setToolTipText("Perform histogram equalisation");
/*      */     
/*  286 */     JRadioButton rdbtnSharpen = new JRadioButton("Sharpen");
/*  287 */     rdbtnSharpen.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  291 */             Sharpen s = new Sharpen();
/*      */             
/*  293 */             BufferedImage sharpenImage = s.sharpenImage(BankNotesRecognitionSystem.this.fileName);
/*  294 */             BankNotesRecognitionSystem.this.processedImage = sharpenImage;
/*  295 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  296 */             BankNotesRecognitionSystem.this.processedFile = "Sharpen_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  298 */             Image newImage = sharpenImage.getScaledInstance(350, 150, 4);
/*  299 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  300 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/*  304 */     rdbtnSharpen.setToolTipText("Sharpen the image");
/*  305 */     this.buttonGroup.add(rdbtnSharpen);
/*      */     
/*  307 */     JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Thresholding");
/*  308 */     rdbtnNewRadioButton_1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent arg0) { BufferedImage threshImage;
/*      */             Image newImage;
/*      */             ImageIcon newIcon;
/*  311 */             int choice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1: Binary Thresholding\nEnter 2: Binary Invert Thresholding\nEnter 3: Zero Thresholding"));
/*      */             
/*  313 */             Thresholding t = new Thresholding(BankNotesRecognitionSystem.this.fileName);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  318 */             switch (choice) {
/*      */               case 1:
/*  320 */                 threshImage = t.ThreshBinary();
/*  321 */                 BankNotesRecognitionSystem.this.processedImage = threshImage;
/*  322 */                 BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  323 */                 BankNotesRecognitionSystem.this.processedFile = "BinaryThresh_" + BankNotesRecognitionSystem.this.fileName;
/*      */                 
/*  325 */                 newImage = threshImage.getScaledInstance(350, 150, 4);
/*  326 */                 newIcon = new ImageIcon(newImage);
/*  327 */                 lblProcessedImage.setIcon(newIcon);
/*      */                 return;
/*      */               case 2:
/*  330 */                 threshImage = t.ThreshBinaryInv();
/*  331 */                 BankNotesRecognitionSystem.this.processedImage = threshImage;
/*  332 */                 BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  333 */                 BankNotesRecognitionSystem.this.processedFile = "BinaryInvThresh_" + BankNotesRecognitionSystem.this.fileName;
/*      */                 
/*  335 */                 newImage = threshImage.getScaledInstance(350, 150, 4);
/*  336 */                 newIcon = new ImageIcon(newImage);
/*  337 */                 lblProcessedImage.setIcon(newIcon);
/*      */                 return;
/*      */               case 3:
/*  340 */                 threshImage = t.ThreshToZero();
/*  341 */                 BankNotesRecognitionSystem.this.processedImage = threshImage;
/*  342 */                 BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  343 */                 BankNotesRecognitionSystem.this.processedFile = "ZeroThresh_" + BankNotesRecognitionSystem.this.fileName;
/*      */                 
/*  345 */                 newImage = threshImage.getScaledInstance(350, 150, 4);
/*  346 */                 newIcon = new ImageIcon(newImage);
/*  347 */                 lblProcessedImage.setIcon(newIcon);
/*      */                 return;
/*      */             } 
/*      */             
/*  351 */             System.out.println("Invalid Entry!"); }
/*      */            }
/*      */       );
/*      */     
/*  355 */     rdbtnNewRadioButton_1.setToolTipText("Apply thresholding ");
/*  356 */     this.buttonGroup.add(rdbtnNewRadioButton_1);
/*      */     
/*  358 */     JRadioButton rdbtnNegative = new JRadioButton("Negative");
/*  359 */     rdbtnNegative.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0) {
/*  362 */             Negative n = new Negative();
/*      */             
/*  364 */             File input = new File(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  366 */             Image negImage = n.negative(input);
/*      */             
/*  368 */             BankNotesRecognitionSystem.this.processedImage = negImage;
/*  369 */             BankNotesRecognitionSystem.this.processedFile = "Negative_" + BankNotesRecognitionSystem.this.fileName;
/*  370 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*      */             
/*  372 */             Image newImage = negImage.getScaledInstance(350, 150, 4);
/*  373 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  374 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/*  378 */     this.buttonGroup.add(rdbtnNegative);
/*  379 */     GroupLayout gl_ImagePreprocessing = new GroupLayout(ImagePreprocessing);
/*  380 */     gl_ImagePreprocessing.setHorizontalGroup(
/*  381 */         gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  382 */         .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  383 */           .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  384 */             .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  385 */               .addGap(7)
/*  386 */               .addComponent(label))
/*  387 */             .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  388 */               .addGap(11)
/*  389 */               .addComponent(rdbtnNewRadioButton))
/*  390 */             .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  391 */               .addGap(11)
/*  392 */               .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  393 */                 .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  394 */                   .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  395 */                     .addComponent(alphaSlider, -2, 109, -2)
/*  396 */                     .addComponent(rdbtnGrayscale)
/*  397 */                     .addComponent(rdbtnNewRadioButton_1)
/*  398 */                     .addComponent(rdbtnSharpen))
/*  399 */                   .addGap(18)
/*  400 */                   .addComponent(betaSlider, -2, 106, -2))
/*  401 */                 .addComponent(rdbtnHistogramEqualisation)
/*  402 */                 .addComponent(rdbtnNegative))))
/*  403 */           .addContainerGap())
/*  404 */         .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  405 */           .addGap(50)
/*  406 */           .addComponent(lblAlpha)
/*  407 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 103, 32767)
/*  408 */           .addComponent(lblBeta)
/*  409 */           .addGap(52)));
/*      */     
/*  411 */     gl_ImagePreprocessing.setVerticalGroup(
/*  412 */         gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  413 */         .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  414 */           .addGap(7)
/*  415 */           .addComponent(label)
/*  416 */           .addGap(5)
/*  417 */           .addComponent(rdbtnNewRadioButton)
/*  418 */           .addGap(4)
/*  419 */           .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.BASELINE)
/*  420 */             .addComponent(lblAlpha)
/*  421 */             .addComponent(lblBeta))
/*  422 */           .addGap(4)
/*  423 */           .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  424 */             .addComponent(alphaSlider, -2, -1, -2)
/*  425 */             .addComponent(betaSlider, -2, -1, -2))
/*  426 */           .addGroup(gl_ImagePreprocessing.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  427 */             .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  428 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/*  429 */               .addComponent(rdbtnGrayscale))
/*  430 */             .addGroup(gl_ImagePreprocessing.createSequentialGroup()
/*  431 */               .addGap(28)
/*  432 */               .addComponent(rdbtnHistogramEqualisation)))
/*  433 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/*  434 */           .addComponent(rdbtnNegative)
/*  435 */           .addGap(2)
/*  436 */           .addComponent(rdbtnSharpen)
/*  437 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/*  438 */           .addComponent(rdbtnNewRadioButton_1)
/*  439 */           .addGap(25)));
/*      */     
/*  441 */     ImagePreprocessing.setLayout(gl_ImagePreprocessing);
/*      */     
/*  443 */     JPanel panel_1 = new JPanel();
/*  444 */     panel_1.setBorder(new TitledBorder(new BevelBorder(1, null, null, null, null), "Segmentation", 2, 2, null, null));
/*  445 */     panel_1.setBounds(611, 191, 263, 71);
/*  446 */     panel.add(panel_1);
/*  447 */     GridBagLayout gbl_panel_1 = new GridBagLayout();
/*  448 */     gbl_panel_1.columnWidths = new int[] { 69, 59, 59 };
/*  449 */     gbl_panel_1.rowHeights = new int[] { 23, 23 };
/*  450 */     gbl_panel_1.columnWeights = new double[] { 0.0D, 0.0D, 0.0D, Double.MIN_VALUE };
/*  451 */     gbl_panel_1.rowWeights = new double[] { 0.0D, 0.0D, Double.MIN_VALUE };
/*  452 */     panel_1.setLayout(gbl_panel_1);
/*      */     
/*  454 */     JRadioButton rdbtnLaplacian = new JRadioButton("Laplacian");
/*  455 */     this.buttonGroup.add(rdbtnLaplacian);
/*  456 */     rdbtnLaplacian.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  460 */             EdgeDetectors l = new EdgeDetectors(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  462 */             BufferedImage laplacian = l.Laplacian();
/*  463 */             BankNotesRecognitionSystem.this.processedImage = laplacian;
/*  464 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  465 */             BankNotesRecognitionSystem.this.processedFile = "Laplacian_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  467 */             Image newImage = laplacian.getScaledInstance(350, 150, 4);
/*  468 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  469 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  472 */     GridBagConstraints gbc_rdbtnLaplacian = new GridBagConstraints();
/*  473 */     gbc_rdbtnLaplacian.anchor = 18;
/*  474 */     gbc_rdbtnLaplacian.insets = new Insets(0, 0, 5, 5);
/*  475 */     gbc_rdbtnLaplacian.gridx = 0;
/*  476 */     gbc_rdbtnLaplacian.gridy = 0;
/*  477 */     panel_1.add(rdbtnLaplacian, gbc_rdbtnLaplacian);
/*      */     
/*  479 */     JRadioButton rdbtnPrewitt = new JRadioButton("Prewitt");
/*  480 */     this.buttonGroup.add(rdbtnPrewitt);
/*  481 */     rdbtnPrewitt.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  485 */             EdgeDetectors p = new EdgeDetectors(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  487 */             BufferedImage prewitt = p.Prewitt();
/*  488 */             BankNotesRecognitionSystem.this.processedImage = prewitt;
/*  489 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  490 */             BankNotesRecognitionSystem.this.processedFile = "Prewitt_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  492 */             Image newImage = prewitt.getScaledInstance(350, 150, 4);
/*  493 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  494 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  497 */     GridBagConstraints gbc_rdbtnPrewitt = new GridBagConstraints();
/*  498 */     gbc_rdbtnPrewitt.anchor = 18;
/*  499 */     gbc_rdbtnPrewitt.insets = new Insets(0, 0, 5, 0);
/*  500 */     gbc_rdbtnPrewitt.gridx = 2;
/*  501 */     gbc_rdbtnPrewitt.gridy = 0;
/*  502 */     panel_1.add(rdbtnPrewitt, gbc_rdbtnPrewitt);
/*      */     
/*  504 */     JRadioButton rdbtnRobinson = new JRadioButton("Robinson");
/*  505 */     this.buttonGroup.add(rdbtnRobinson);
/*  506 */     rdbtnRobinson.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  510 */             EdgeDetectors r = new EdgeDetectors(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  512 */             BufferedImage robinson = r.Robinson();
/*  513 */             BankNotesRecognitionSystem.this.processedImage = robinson;
/*  514 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  515 */             BankNotesRecognitionSystem.this.processedFile = "Robinson_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  517 */             Image newImage = robinson.getScaledInstance(350, 150, 4);
/*  518 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  519 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  522 */     GridBagConstraints gbc_rdbtnRobinson = new GridBagConstraints();
/*  523 */     gbc_rdbtnRobinson.anchor = 18;
/*  524 */     gbc_rdbtnRobinson.insets = new Insets(0, 0, 0, 5);
/*  525 */     gbc_rdbtnRobinson.gridx = 0;
/*  526 */     gbc_rdbtnRobinson.gridy = 1;
/*  527 */     panel_1.add(rdbtnRobinson, gbc_rdbtnRobinson);
/*      */     
/*  529 */     JRadioButton rdbtnSobel = new JRadioButton("Sobel");
/*  530 */     this.buttonGroup.add(rdbtnSobel);
/*  531 */     rdbtnSobel.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  535 */             EdgeDetectors s = new EdgeDetectors(BankNotesRecognitionSystem.this.fileName);
/*      */             
/*  537 */             BufferedImage sobel = s.Sobel();
/*  538 */             BankNotesRecognitionSystem.this.processedImage = sobel;
/*  539 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  540 */             BankNotesRecognitionSystem.this.processedFile = "Sobel_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  542 */             Image newImage = sobel.getScaledInstance(350, 150, 4);
/*  543 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  544 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  547 */     GridBagConstraints gbc_rdbtnSobel = new GridBagConstraints();
/*  548 */     gbc_rdbtnSobel.anchor = 18;
/*  549 */     gbc_rdbtnSobel.gridx = 2;
/*  550 */     gbc_rdbtnSobel.gridy = 1;
/*  551 */     panel_1.add(rdbtnSobel, gbc_rdbtnSobel);
/*      */     
/*  553 */     JPanel panel_3 = new JPanel();
/*  554 */     panel_3.setBorder(new TitledBorder(new BevelBorder(1, null, null, null, null), "Feature Extraction and Classification", 2, 2, null, new Color(0, 0, 0)));
/*  555 */     panel_3.setBounds(468, 275, 263, 165);
/*  556 */     panel.add(panel_3);
/*  557 */     panel_3.setLayout((LayoutManager)null);
/*      */     
/*  559 */     final JLabel lblResult = new JLabel("CLASSIFICATION");
/*  560 */     lblResult.setFont(new Font("Tahoma", 0, 13));
/*  561 */     lblResult.setHorizontalAlignment(0);
/*  562 */     lblResult.setBounds(10, 90, 243, 30);
/*  563 */     panel_3.add(lblResult);
/*      */     
/*  565 */     JButton btnClassify = new JButton("Classify");
/*  566 */     btnClassify.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  570 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  571 */             Mat source = Highgui.imread("old10fronteq.jpg", 0);
/*  572 */             Mat fin = new Mat(source.rows(), source.cols(), source.type());
/*  573 */             Imgproc.equalizeHist(source, fin);
/*  574 */             List<MatOfPoint> contours = new ArrayList<>();
/*  575 */             Imgproc.findContours(source, contours, new Mat(), 1, 2);
/*  576 */             Moments mom = new Moments();
/*  577 */             mom = Imgproc.moments((Mat)contours.get(0), false);
/*  578 */             Mat oldTenFrontHu = new Mat();
/*  579 */             Imgproc.HuMoments(mom, oldTenFrontHu);
/*      */ 
/*      */             
/*  582 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  583 */             Mat sourcetb = Highgui.imread("old10backeq.jpg", 0);
/*  584 */             Mat fintb = new Mat(sourcetb.rows(), sourcetb.cols(), sourcetb.type());
/*  585 */             Imgproc.equalizeHist(sourcetb, fintb);
/*  586 */             List<MatOfPoint> contourstb = new ArrayList<>();
/*  587 */             Imgproc.findContours(sourcetb, contourstb, new Mat(), 1, 2);
/*  588 */             Moments momtb = new Moments();
/*  589 */             momtb = Imgproc.moments((Mat)contourstb.get(0), false);
/*  590 */             Mat oldTenBackHu = new Mat();
/*  591 */             Imgproc.HuMoments(momtb, oldTenBackHu);
/*      */ 
/*      */             
/*  594 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  595 */             Mat sourcenewten = Highgui.imread("new10fronteq.jpg", 0);
/*  596 */             Mat finnew10 = new Mat(sourcenewten.rows(), sourcenewten.cols(), sourcenewten.type());
/*  597 */             Imgproc.equalizeHist(sourcenewten, finnew10);
/*  598 */             List<MatOfPoint> contoursnew10 = new ArrayList<>();
/*  599 */             Imgproc.findContours(sourcenewten, contoursnew10, new Mat(), 1, 2);
/*  600 */             Moments momn10 = new Moments();
/*  601 */             momn10 = Imgproc.moments((Mat)contoursnew10.get(0), false);
/*  602 */             Mat newTenFrontHu = new Mat();
/*  603 */             Imgproc.HuMoments(momn10, newTenFrontHu);
/*      */ 
/*      */             
/*  606 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  607 */             Mat sn10b = Highgui.imread("new10backeq.jpg", 0);
/*  608 */             Mat fn10b = new Mat(sn10b.rows(), sn10b.cols(), sn10b.type());
/*  609 */             Imgproc.equalizeHist(sn10b, fn10b);
/*  610 */             List<MatOfPoint> cn10b = new ArrayList<>();
/*  611 */             Imgproc.findContours(sn10b, cn10b, new Mat(), 1, 2);
/*  612 */             Moments mn10b = new Moments();
/*  613 */             mn10b = Imgproc.moments((Mat)cn10b.get(0), false);
/*  614 */             Mat newTenBackHu = new Mat();
/*  615 */             Imgproc.HuMoments(mn10b, newTenBackHu);
/*      */ 
/*      */             
/*  618 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  619 */             Mat so20f = Highgui.imread("old20fronteq.jpg", 0);
/*  620 */             Mat f020f = new Mat(so20f.rows(), so20f.cols(), so20f.type());
/*  621 */             Imgproc.equalizeHist(so20f, f020f);
/*  622 */             List<MatOfPoint> co20f = new ArrayList<>();
/*  623 */             Imgproc.findContours(so20f, co20f, new Mat(), 1, 2);
/*  624 */             Moments mo20f = new Moments();
/*  625 */             mo20f = Imgproc.moments((Mat)co20f.get(0), false);
/*  626 */             Mat oldTwentyFrontHu = new Mat();
/*  627 */             Imgproc.HuMoments(mo20f, oldTwentyFrontHu);
/*      */ 
/*      */             
/*  630 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  631 */             Mat so20b = Highgui.imread("old20backeq.jpg", 0);
/*  632 */             Mat f020b = new Mat(so20b.rows(), so20b.cols(), so20b.type());
/*  633 */             Imgproc.equalizeHist(so20b, f020b);
/*  634 */             List<MatOfPoint> co20b = new ArrayList<>();
/*  635 */             Imgproc.findContours(so20b, co20b, new Mat(), 1, 2);
/*  636 */             Moments mo20b = new Moments();
/*  637 */             mo20b = Imgproc.moments((Mat)co20f.get(0), false);
/*  638 */             Mat oldTwentyBackHu = new Mat();
/*  639 */             Imgproc.HuMoments(mo20b, oldTwentyBackHu);
/*      */ 
/*      */             
/*  642 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  643 */             Mat sn20f = Highgui.imread("new20fronteq.jpg", 0);
/*  644 */             Mat fn20f = new Mat(sn20f.rows(), sn20f.cols(), sn20f.type());
/*  645 */             Imgproc.equalizeHist(sn20f, fn20f);
/*  646 */             List<MatOfPoint> cn20f = new ArrayList<>();
/*  647 */             Imgproc.findContours(sn20f, cn20f, new Mat(), 1, 2);
/*  648 */             Moments mn20f = new Moments();
/*  649 */             mn20f = Imgproc.moments((Mat)cn20f.get(0), false);
/*  650 */             Mat newTwentyFrontHu = new Mat();
/*  651 */             Imgproc.HuMoments(mn20f, newTwentyFrontHu);
/*      */ 
/*      */             
/*  654 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  655 */             Mat sn20b = Highgui.imread("new20backeq.jpg", 0);
/*  656 */             Mat fn20b = new Mat(sn20b.rows(), sn20b.cols(), sn20b.type());
/*  657 */             Imgproc.equalizeHist(sn20b, fn20b);
/*  658 */             List<MatOfPoint> cn20b = new ArrayList<>();
/*  659 */             Imgproc.findContours(sn20b, cn20b, new Mat(), 1, 2);
/*  660 */             Moments mn20b = new Moments();
/*  661 */             mn20b = Imgproc.moments((Mat)cn20b.get(0), false);
/*  662 */             Mat newTwentyBackHu = new Mat();
/*  663 */             Imgproc.HuMoments(mn20b, newTwentyBackHu);
/*      */ 
/*      */             
/*  666 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  667 */             Mat so50f = Highgui.imread("old50fronteq.jpg", 0);
/*  668 */             Mat f050f = new Mat(so50f.rows(), so50f.cols(), so50f.type());
/*  669 */             Imgproc.equalizeHist(so50f, f050f);
/*  670 */             List<MatOfPoint> co50f = new ArrayList<>();
/*  671 */             Imgproc.findContours(so50f, co50f, new Mat(), 1, 2);
/*  672 */             Moments mo50f = new Moments();
/*  673 */             mo50f = Imgproc.moments((Mat)co50f.get(0), false);
/*  674 */             Mat oldFiftyFrontHu = new Mat();
/*  675 */             Imgproc.HuMoments(mo50f, oldFiftyFrontHu);
/*      */ 
/*      */             
/*  678 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  679 */             Mat so50b = Highgui.imread("old50backeq.jpg", 0);
/*  680 */             Mat f050b = new Mat(so50b.rows(), so50b.cols(), so50b.type());
/*  681 */             Imgproc.equalizeHist(so50b, f050b);
/*  682 */             List<MatOfPoint> co50b = new ArrayList<>();
/*  683 */             Imgproc.findContours(so50b, co50b, new Mat(), 1, 2);
/*  684 */             Moments mo50b = new Moments();
/*  685 */             mo50b = Imgproc.moments((Mat)co50b.get(0), false);
/*  686 */             Mat oldFiftyBackHu = new Mat();
/*  687 */             Imgproc.HuMoments(mo50b, oldFiftyBackHu);
/*      */ 
/*      */             
/*  690 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  691 */             Mat sn50f = Highgui.imread("new50fronteq.jpg", 0);
/*  692 */             Mat fn50f = new Mat(sn50f.rows(), sn50f.cols(), sn50f.type());
/*  693 */             Imgproc.equalizeHist(sn50f, fn50f);
/*  694 */             List<MatOfPoint> cn50f = new ArrayList<>();
/*  695 */             Imgproc.findContours(sn50f, cn50f, new Mat(), 1, 2);
/*  696 */             Moments mn50f = new Moments();
/*  697 */             mn50f = Imgproc.moments((Mat)cn50f.get(0), false);
/*  698 */             Mat newFiftyFrontHu = new Mat();
/*  699 */             Imgproc.HuMoments(mn50f, newFiftyFrontHu);
/*      */ 
/*      */             
/*  702 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  703 */             Mat sn50b = Highgui.imread("new50backeq.jpg", 0);
/*  704 */             Mat fn50b = new Mat(sn50b.rows(), sn50b.cols(), sn50b.type());
/*  705 */             Imgproc.equalizeHist(sn50b, fn50b);
/*  706 */             List<MatOfPoint> cn50b = new ArrayList<>();
/*  707 */             Imgproc.findContours(sn50b, cn50b, new Mat(), 1, 2);
/*  708 */             Moments mn50b = new Moments();
/*  709 */             mn50b = Imgproc.moments((Mat)cn50b.get(0), false);
/*  710 */             Mat newFiftyBackHu = new Mat();
/*  711 */             Imgproc.HuMoments(mn50b, newFiftyBackHu);
/*      */ 
/*      */             
/*  714 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  715 */             Mat so100f = Highgui.imread("old100fronteq.jpg", 0);
/*  716 */             Mat f0100f = new Mat(so100f.rows(), so100f.cols(), so100f.type());
/*  717 */             Imgproc.equalizeHist(so100f, f0100f);
/*  718 */             List<MatOfPoint> co100f = new ArrayList<>();
/*  719 */             Imgproc.findContours(so100f, co100f, new Mat(), 1, 2);
/*  720 */             Moments mo100f = new Moments();
/*  721 */             mo100f = Imgproc.moments((Mat)co100f.get(0), false);
/*  722 */             Mat oldOneHFrontHu = new Mat();
/*  723 */             Imgproc.HuMoments(mo100f, oldOneHFrontHu);
/*      */ 
/*      */             
/*  726 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  727 */             Mat so100b = Highgui.imread("old100backeq.jpg", 0);
/*  728 */             Mat f0100b = new Mat(so100b.rows(), so100b.cols(), so100b.type());
/*  729 */             Imgproc.equalizeHist(so100b, f0100b);
/*  730 */             List<MatOfPoint> co100b = new ArrayList<>();
/*  731 */             Imgproc.findContours(so100b, co100b, new Mat(), 1, 2);
/*  732 */             Moments mo100b = new Moments();
/*  733 */             mo100b = Imgproc.moments((Mat)co100b.get(0), false);
/*  734 */             Mat oldOneHBackHu = new Mat();
/*  735 */             Imgproc.HuMoments(mo100b, oldOneHBackHu);
/*      */ 
/*      */             
/*  738 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  739 */             Mat sn100f = Highgui.imread("new100fronteq.jpg", 0);
/*  740 */             Mat fn100f = new Mat(sn100f.rows(), sn100f.cols(), sn100f.type());
/*  741 */             Imgproc.equalizeHist(sn100f, fn100f);
/*  742 */             List<MatOfPoint> cn100f = new ArrayList<>();
/*  743 */             Imgproc.findContours(sn100f, cn100f, new Mat(), 1, 2);
/*  744 */             Moments mn100f = new Moments();
/*  745 */             mn100f = Imgproc.moments((Mat)cn100f.get(0), false);
/*  746 */             Mat newOneHFrontHu = new Mat();
/*  747 */             Imgproc.HuMoments(mn100f, newOneHFrontHu);
/*      */ 
/*      */             
/*  750 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  751 */             Mat sn100b = Highgui.imread("new100backeq.jpg", 0);
/*  752 */             Mat fn100b = new Mat(sn100b.rows(), sn100b.cols(), sn100b.type());
/*  753 */             Imgproc.equalizeHist(sn100b, fn100b);
/*  754 */             List<MatOfPoint> cn100b = new ArrayList<>();
/*  755 */             Imgproc.findContours(sn100b, cn100b, new Mat(), 1, 2);
/*  756 */             Moments mn100b = new Moments();
/*  757 */             mn100b = Imgproc.moments((Mat)cn100b.get(0), false);
/*  758 */             Mat newOneHBackHu = new Mat();
/*  759 */             Imgproc.HuMoments(mn100b, newOneHBackHu);
/*      */ 
/*      */             
/*  762 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  763 */             Mat so200f = Highgui.imread("old200fronteq.jpg", 0);
/*  764 */             Mat f0200f = new Mat(so200f.rows(), so200f.cols(), so200f.type());
/*  765 */             Imgproc.equalizeHist(so200f, f0200f);
/*  766 */             List<MatOfPoint> co200f = new ArrayList<>();
/*  767 */             Imgproc.findContours(so200f, co200f, new Mat(), 1, 2);
/*  768 */             Moments mo200f = new Moments();
/*  769 */             mo200f = Imgproc.moments((Mat)co100f.get(0), false);
/*  770 */             Mat oldTwoHFrontHu = new Mat();
/*  771 */             Imgproc.HuMoments(mo200f, oldTwoHFrontHu);
/*      */ 
/*      */             
/*  774 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  775 */             Mat so200b = Highgui.imread("old200backeq.jpg", 0);
/*  776 */             Mat f0200b = new Mat(so200b.rows(), so200b.cols(), so200b.type());
/*  777 */             Imgproc.equalizeHist(so200b, f0200b);
/*  778 */             List<MatOfPoint> co200b = new ArrayList<>();
/*  779 */             Imgproc.findContours(so200b, co200b, new Mat(), 1, 2);
/*  780 */             Moments mo200b = new Moments();
/*  781 */             mo200b = Imgproc.moments((Mat)co200b.get(0), false);
/*  782 */             Mat oldTwoHBackHu = new Mat();
/*  783 */             Imgproc.HuMoments(mo200b, oldTwoHBackHu);
/*      */ 
/*      */             
/*  786 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  787 */             Mat sn200f = Highgui.imread("new200fronteq.jpg", 0);
/*  788 */             Mat fn200f = new Mat(sn200f.rows(), sn200f.cols(), sn200f.type());
/*  789 */             Imgproc.equalizeHist(sn200f, fn200f);
/*  790 */             List<MatOfPoint> cn200f = new ArrayList<>();
/*  791 */             Imgproc.findContours(sn200f, cn200f, new Mat(), 1, 2);
/*  792 */             Moments mn200f = new Moments();
/*  793 */             mn200f = Imgproc.moments((Mat)cn200f.get(0), false);
/*  794 */             Mat newTwoHFrontHu = new Mat();
/*  795 */             Imgproc.HuMoments(mn200f, newTwoHFrontHu);
/*      */ 
/*      */             
/*  798 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  799 */             Mat sn200b = Highgui.imread("new200backeq.jpg", 0);
/*  800 */             Mat fn200b = new Mat(sn200b.rows(), sn200b.cols(), sn200b.type());
/*  801 */             Imgproc.equalizeHist(sn200b, fn200b);
/*  802 */             List<MatOfPoint> cn200b = new ArrayList<>();
/*  803 */             Imgproc.findContours(sn200b, cn200b, new Mat(), 1, 2);
/*  804 */             Moments mn200b = new Moments();
/*  805 */             mn200b = Imgproc.moments((Mat)cn200b.get(0), false);
/*  806 */             Mat newTwoHBackHu = new Mat();
/*  807 */             Imgproc.HuMoments(mn200b, newTwoHBackHu);
/*      */ 
/*      */             
/*  810 */             GrayScale_2 gs = new GrayScale_2();
/*  811 */             File in = new File(BankNotesRecognitionSystem.this.restoreFile);
/*  812 */             System.out.println("Original File -> " + BankNotesRecognitionSystem.this.restoreFile);
/*  813 */             CreateBufferedImage cv = new CreateBufferedImage();
/*      */             
/*  815 */             BufferedImage g = cv.createBufferedImage(new File(BankNotesRecognitionSystem.this.restoreFile));
/*      */             try {
/*  817 */               Image image = gs.greyImage(g);
/*  818 */             } catch (Exception exception) {}
/*  819 */             HistogramEqualisation_2 sh = new HistogramEqualisation_2();
/*  820 */             Mat shim = sh.histogram("grayscale.jpg");
/*      */             
/*  822 */             Image x7 = BankNotesRecognitionSystem.x.Mat2BufferedImage(shim);
/*      */             
/*  824 */             System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  825 */             Mat st = Highgui.imread("equalisation.jpg", 0);
/*  826 */             Mat ft = new Mat(st.rows(), st.cols(), st.type());
/*  827 */             Imgproc.equalizeHist(st, ft);
/*  828 */             List<MatOfPoint> ct = new ArrayList<>();
/*  829 */             Imgproc.findContours(st, ct, new Mat(), 1, 2);
/*  830 */             Moments mt = new Moments();
/*  831 */             mt = Imgproc.moments((Mat)ct.get(0), false);
/*  832 */             Mat HuTest = new Mat();
/*  833 */             Imgproc.HuMoments(mt, HuTest);
/*      */ 
/*      */             
/*  836 */             for (int k = 0; k < 7; k++) {
/*  837 */               if (HuTest.get(k, 0)[0] == oldTenFrontHu.get(k, 0)[0]) {
/*  838 */                 lblResult.setText("OLD TEN RAND");
/*      */               
/*      */               }
/*  841 */               else if (HuTest.get(k, 0)[0] == oldTenBackHu.get(k, 0)[0]) {
/*  842 */                 lblResult.setText("OLD TEN RAND");
/*      */               
/*      */               }
/*  845 */               else if (HuTest.get(k, 0)[0] == newTenFrontHu.get(k, 0)[0]) {
/*  846 */                 lblResult.setText("NEW TEN RAND");
/*      */               
/*      */               }
/*  849 */               else if (HuTest.get(k, 0)[0] == newTenBackHu.get(k, 0)[0]) {
/*  850 */                 lblResult.setText("NEW TEN RAND");
/*      */               
/*      */               }
/*  853 */               else if (HuTest.get(k, 0)[0] == oldTwentyFrontHu.get(k, 0)[0]) {
/*  854 */                 lblResult.setText("OLD TWENTY RAND");
/*      */               
/*      */               }
/*  857 */               else if (HuTest.get(k, 0)[0] == oldTwentyBackHu.get(k, 0)[0]) {
/*  858 */                 lblResult.setText("OLD TWENTY RAND");
/*      */               
/*      */               }
/*  861 */               else if (HuTest.get(k, 0)[0] == newTwentyFrontHu.get(k, 0)[0]) {
/*  862 */                 lblResult.setText("NEW TWENTY RAND");
/*      */               
/*      */               }
/*  865 */               else if (HuTest.get(k, 0)[0] == newTwentyBackHu.get(k, 0)[0]) {
/*  866 */                 lblResult.setText("NEW TWENTY RAND");
/*      */               
/*      */               }
/*  869 */               else if (HuTest.get(k, 0)[0] == oldFiftyFrontHu.get(k, 0)[0]) {
/*  870 */                 lblResult.setText("OLD FIFTY RAND");
/*      */               
/*      */               }
/*  873 */               else if (HuTest.get(k, 0)[0] == oldFiftyBackHu.get(k, 0)[0]) {
/*  874 */                 lblResult.setText("OLD FIFTY RAND");
/*      */               
/*      */               }
/*  877 */               else if (HuTest.get(k, 0)[0] == newFiftyFrontHu.get(k, 0)[0]) {
/*  878 */                 lblResult.setText("NEW FIFTY RAND");
/*      */               
/*      */               }
/*  881 */               else if (HuTest.get(k, 0)[0] == newFiftyBackHu.get(k, 0)[0]) {
/*  882 */                 lblResult.setText("NEW FIFTY RAND");
/*      */               
/*      */               }
/*  885 */               else if (HuTest.get(k, 0)[0] == oldOneHFrontHu.get(k, 0)[0]) {
/*  886 */                 lblResult.setText("OLD ONE HUNDRED RAND");
/*      */               
/*      */               }
/*  889 */               else if (HuTest.get(k, 0)[0] == oldOneHBackHu.get(k, 0)[0]) {
/*  890 */                 lblResult.setText("OLD ONE HUNDRED RAND");
/*      */               
/*      */               }
/*  893 */               else if (HuTest.get(k, 0)[0] == newOneHFrontHu.get(k, 0)[0]) {
/*  894 */                 lblResult.setText("NEW ONE HUNDRED RAND");
/*      */               
/*      */               }
/*  897 */               else if (HuTest.get(k, 0)[0] == newOneHBackHu.get(k, 0)[0]) {
/*  898 */                 lblResult.setText("NEW ONE HUNDRED RAND");
/*      */               
/*      */               }
/*  901 */               else if (HuTest.get(k, 0)[0] == oldTwoHFrontHu.get(k, 0)[0]) {
/*  902 */                 lblResult.setText("OLD TWO HUNDRED RAND");
/*      */               
/*      */               }
/*  905 */               else if (HuTest.get(k, 0)[0] == oldTwoHBackHu.get(k, 0)[0]) {
/*  906 */                 lblResult.setText("OLD TWO HUNDRED RAND");
/*      */               
/*      */               }
/*  909 */               else if (HuTest.get(k, 0)[0] == newTwoHFrontHu.get(k, 0)[0]) {
/*  910 */                 lblResult.setText("NEW TWO HUNDRED RAND");
/*      */               
/*      */               }
/*  913 */               else if (HuTest.get(k, 0)[0] == newTwoHBackHu.get(k, 0)[0]) {
/*  914 */                 lblResult.setText("NEW TWO HUNDRED RAND");
/*      */               } 
/*      */             } 
/*      */           }
/*      */         });
/*      */     
/*  920 */     btnClassify.setBounds(92, 34, 85, 23);
/*  921 */     panel_3.add(btnClassify);
/*      */     
/*  923 */     JPanel panel_4 = new JPanel();
/*  924 */     panel_4.setBorder(new TitledBorder(new BevelBorder(1, null, null, null, null), "Spatial Filtering", 2, 2, null, null));
/*  925 */     panel_4.setBounds(611, 24, 263, 71);
/*  926 */     panel.add(panel_4);
/*  927 */     GridBagLayout gbl_panel_4 = new GridBagLayout();
/*  928 */     gbl_panel_4.columnWidths = new int[] { 97, 115 };
/*  929 */     gbl_panel_4.rowHeights = new int[] { 12, 12 };
/*  930 */     gbl_panel_4.columnWeights = new double[] { 0.0D, 0.0D, Double.MIN_VALUE };
/*  931 */     gbl_panel_4.rowWeights = new double[] { 0.0D, 0.0D, Double.MIN_VALUE };
/*  932 */     panel_4.setLayout(gbl_panel_4);
/*      */     
/*  934 */     JRadioButton rdbtnBilateral = new JRadioButton("Bilateral");
/*  935 */     this.buttonGroup.add(rdbtnBilateral);
/*  936 */     rdbtnBilateral.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  940 */             Filters b = new Filters();
/*      */             
/*  942 */             BufferedImage bilateralImage = b.bilateral(BankNotesRecognitionSystem.this.fileName, 15, 80.0D, 80.0D);
/*  943 */             BankNotesRecognitionSystem.this.processedImage = bilateralImage;
/*  944 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  945 */             BankNotesRecognitionSystem.this.processedFile = "Bilateral_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  947 */             Image newImage = bilateralImage.getScaledInstance(350, 150, 4);
/*  948 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  949 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*  952 */     GridBagConstraints gbc_rdbtnBilateral = new GridBagConstraints();
/*  953 */     gbc_rdbtnBilateral.fill = 1;
/*  954 */     gbc_rdbtnBilateral.insets = new Insets(0, 0, 5, 5);
/*  955 */     gbc_rdbtnBilateral.gridx = 0;
/*  956 */     gbc_rdbtnBilateral.gridy = 0;
/*  957 */     panel_4.add(rdbtnBilateral, gbc_rdbtnBilateral);
/*      */     
/*  959 */     JRadioButton rdbtnMedian = new JRadioButton("Median");
/*  960 */     this.buttonGroup.add(rdbtnMedian);
/*  961 */     rdbtnMedian.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  965 */             Filters m = new Filters();
/*      */             
/*  967 */             int size = Integer.parseInt(JOptionPane.showInputDialog("Enter the size of the Median Kernal. Size must be an odd number > 0"));
/*  968 */             while (size < 0 || size % 2 == 0) {
/*  969 */               size = Integer.parseInt(JOptionPane.showInputDialog("Enter the size of the Median Kernal. Size must be an odd number > 0"));
/*      */             }
/*  971 */             BufferedImage medianImage = m.median(BankNotesRecognitionSystem.this.fileName, size);
/*  972 */             BankNotesRecognitionSystem.this.processedImage = medianImage;
/*  973 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  974 */             BankNotesRecognitionSystem.this.processedFile = "Gaussian_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/*  976 */             Image newImage = medianImage.getScaledInstance(350, 150, 4);
/*  977 */             ImageIcon newIcon = new ImageIcon(newImage);
/*  978 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  983 */     JRadioButton rdbtnGaussian = new JRadioButton("Gaussian");
/*  984 */     this.buttonGroup.add(rdbtnGaussian);
/*  985 */     rdbtnGaussian.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/*  989 */             Filters g = new Filters();
/*      */             
/*  991 */             int size = Integer.parseInt(JOptionPane.showInputDialog("Enter the size of the Gaussian Kernal. Size must be an odd number > 0"));
/*  992 */             while (size < 0 || size % 2 == 0) {
/*  993 */               size = Integer.parseInt(JOptionPane.showInputDialog("Enter the size of the Gaussian Kernal. Size must be an odd number > 0"));
/*      */             }
/*  995 */             BufferedImage gaussianImage = g.gaussian(BankNotesRecognitionSystem.this.fileName, size);
/*  996 */             BankNotesRecognitionSystem.this.processedImage = gaussianImage;
/*  997 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/*  998 */             BankNotesRecognitionSystem.this.processedFile = "Gaussian_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1000 */             Image newImage = gaussianImage.getScaledInstance(350, 150, 4);
/* 1001 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1002 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/* 1005 */     GridBagConstraints gbc_rdbtnGaussian = new GridBagConstraints();
/* 1006 */     gbc_rdbtnGaussian.fill = 1;
/* 1007 */     gbc_rdbtnGaussian.insets = new Insets(0, 0, 5, 0);
/* 1008 */     gbc_rdbtnGaussian.gridx = 1;
/* 1009 */     gbc_rdbtnGaussian.gridy = 0;
/* 1010 */     panel_4.add(rdbtnGaussian, gbc_rdbtnGaussian);
/* 1011 */     GridBagConstraints gbc_rdbtnMedian = new GridBagConstraints();
/* 1012 */     gbc_rdbtnMedian.fill = 1;
/* 1013 */     gbc_rdbtnMedian.insets = new Insets(0, 0, 0, 5);
/* 1014 */     gbc_rdbtnMedian.gridx = 0;
/* 1015 */     gbc_rdbtnMedian.gridy = 1;
/* 1016 */     panel_4.add(rdbtnMedian, gbc_rdbtnMedian);
/*      */     
/* 1018 */     JRadioButton rdbtnWeightedAverage = new JRadioButton("Weighted Average");
/* 1019 */     this.buttonGroup.add(rdbtnWeightedAverage);
/* 1020 */     rdbtnWeightedAverage.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/* 1024 */             Filters w = new Filters();
/*      */             
/* 1026 */             BufferedImage avgImage = w.WeightedAverage(BankNotesRecognitionSystem.this.fileName);
/* 1027 */             BankNotesRecognitionSystem.this.processedImage = avgImage;
/* 1028 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 1029 */             BankNotesRecognitionSystem.this.processedFile = "WeightedAvg_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1031 */             Image newImage = avgImage.getScaledInstance(350, 150, 4);
/* 1032 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1033 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/* 1036 */     GridBagConstraints gbc_rdbtnWeightedAverage = new GridBagConstraints();
/* 1037 */     gbc_rdbtnWeightedAverage.anchor = 17;
/* 1038 */     gbc_rdbtnWeightedAverage.fill = 3;
/* 1039 */     gbc_rdbtnWeightedAverage.gridx = 1;
/* 1040 */     gbc_rdbtnWeightedAverage.gridy = 1;
/* 1041 */     panel_4.add(rdbtnWeightedAverage, gbc_rdbtnWeightedAverage);
/*      */     
/* 1043 */     JPanel panel_5 = new JPanel();
/* 1044 */     panel_5.setBorder(new TitledBorder(new BevelBorder(1, null, null, null, null), "Morphology", 2, 2, null, null));
/* 1045 */     panel_5.setBounds(611, 106, 263, 71);
/* 1046 */     panel.add(panel_5);
/* 1047 */     panel_5.setLayout(new GridLayout(0, 2, 0, 0));
/*      */     
/* 1049 */     JRadioButton rdbtnDilation = new JRadioButton("Dilation");
/* 1050 */     this.buttonGroup.add(rdbtnDilation);
/* 1051 */     rdbtnDilation.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/* 1055 */             Morphology d = new Morphology(BankNotesRecognitionSystem.this.fileName);
/*      */             
/* 1057 */             BufferedImage dilation = d.dilation();
/* 1058 */             BankNotesRecognitionSystem.this.processedImage = dilation;
/* 1059 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 1060 */             BankNotesRecognitionSystem.this.processedFile = "Dilation_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1062 */             Image newImage = dilation.getScaledInstance(350, 150, 4);
/* 1063 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1064 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/*      */     
/* 1068 */     JRadioButton rdbtnErosion = new JRadioButton("Erosion");
/* 1069 */     this.buttonGroup.add(rdbtnErosion);
/* 1070 */     rdbtnErosion.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/* 1074 */             Morphology e = new Morphology(BankNotesRecognitionSystem.this.fileName);
/*      */             
/* 1076 */             BufferedImage erosion = e.erosion();
/* 1077 */             BankNotesRecognitionSystem.this.processedImage = erosion;
/* 1078 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 1079 */             BankNotesRecognitionSystem.this.processedFile = "Erosion_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1081 */             Image newImage = erosion.getScaledInstance(350, 150, 4);
/* 1082 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1083 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/* 1086 */     panel_5.add(rdbtnErosion);
/*      */     
/* 1088 */     JRadioButton rdbtnOpening = new JRadioButton("Opening");
/* 1089 */     this.buttonGroup.add(rdbtnOpening);
/* 1090 */     rdbtnOpening.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/* 1094 */             Morphology o = new Morphology(BankNotesRecognitionSystem.this.fileName);
/*      */             
/* 1096 */             BufferedImage opening = o.open();
/* 1097 */             BankNotesRecognitionSystem.this.processedImage = opening;
/* 1098 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 1099 */             BankNotesRecognitionSystem.this.processedFile = "Open_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1101 */             Image newImage = opening.getScaledInstance(350, 150, 4);
/* 1102 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1103 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/* 1106 */     panel_5.add(rdbtnOpening);
/* 1107 */     panel_5.add(rdbtnDilation);
/*      */     
/* 1109 */     JRadioButton rdbtnClosing = new JRadioButton("Closing");
/* 1110 */     this.buttonGroup.add(rdbtnClosing);
/* 1111 */     rdbtnClosing.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0)
/*      */           {
/* 1115 */             Morphology c = new Morphology(BankNotesRecognitionSystem.this.fileName);
/*      */             
/* 1117 */             BufferedImage closing = c.close();
/* 1118 */             BankNotesRecognitionSystem.this.processedImage = closing;
/* 1119 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 1120 */             BankNotesRecognitionSystem.this.processedFile = "Close_" + BankNotesRecognitionSystem.this.fileName;
/*      */             
/* 1122 */             Image newImage = closing.getScaledInstance(350, 150, 4);
/* 1123 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1124 */             lblProcessedImage.setIcon(newIcon);
/*      */           }
/*      */         });
/* 1127 */     panel_5.add(rdbtnClosing);
/*      */     
/* 1129 */     JButton btnNewButton = new JButton("Restore Image");
/* 1130 */     btnNewButton.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent arg0) {
/* 1133 */             Image newImage = BankNotesRecognitionSystem.this.restoreImage.getScaledInstance(350, 150, 4);
/* 1134 */             ImageIcon newIcon = new ImageIcon(newImage);
/* 1135 */             pictureLabel.setIcon(newIcon);
/*      */             
/* 1137 */             BankNotesRecognitionSystem.this.fileName = BankNotesRecognitionSystem.this.restoreFile;
/* 1138 */             BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.restoreImage;
/*      */           }
/*      */         });
/* 1141 */     btnNewButton.setBounds(185, 231, 134, 23);
/* 1142 */     panel.add(btnNewButton);
/*      */   }
/*      */   
/*      */   private class SwingAction extends AbstractAction {
/*      */     public SwingAction() {
/* 1147 */       putValue("Name", "SwingAction");
/* 1148 */       putValue("ShortDescription", "Some short description");
/*      */     }
/*      */     
/*      */     public void actionPerformed(ActionEvent e) {}
/*      */   }
/*      */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\BankNotesRecognitionSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */