/*    */ import java.awt.image.BufferedImage;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.highgui.Highgui;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HistogramEqualisation
/*    */ {
/*    */   BufferedImage image;
/*    */   
/*    */   public BufferedImage equaliseHistogram(String input) {
/*    */     try {
/* 21 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 22 */       Mat source = Highgui.imread(input, 0);
/* 23 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 25 */       Imgproc.equalizeHist(source, destination);
/* 26 */       Highgui.imwrite("Histogram_" + input, destination);
/*    */       
/* 28 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 29 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */     }
/* 31 */     catch (Exception e) {
/* 32 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/*    */     
/* 35 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\HistogramEqualisation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */