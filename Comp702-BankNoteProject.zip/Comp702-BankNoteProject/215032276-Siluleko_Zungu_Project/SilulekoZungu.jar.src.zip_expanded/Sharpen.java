/*    */ import java.awt.image.BufferedImage;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.core.Size;
/*    */ import org.opencv.highgui.Highgui;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sharpen
/*    */ {
/*    */   BufferedImage image;
/*    */   
/*    */   public BufferedImage sharpenImage(String input) {
/*    */     try {
/* 22 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 23 */       Mat source = Highgui.imread(input, 1);
/* 24 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*    */       
/* 26 */       Imgproc.GaussianBlur(source, destination, new Size(0.0D, 0.0D), 10.0D);
/* 27 */       Core.addWeighted(source, 1.5D, destination, -0.5D, 0.0D, destination);
/* 28 */       Highgui.imwrite("Sharpen_" + input, destination);
/*    */       
/* 30 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 31 */       this.image = cbi.Mat2BufferedImage(destination);
/*    */     
/*    */     }
/* 34 */     catch (Exception e) {
/*    */       
/* 36 */       System.out.println("Error : " + e.getMessage());
/*    */     } 
/*    */     
/* 39 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Sharpen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */