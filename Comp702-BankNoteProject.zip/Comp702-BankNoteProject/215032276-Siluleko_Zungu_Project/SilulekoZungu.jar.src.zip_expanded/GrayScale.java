/*    */ import java.awt.Color;
/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GrayScale
/*    */ {
/*    */   BufferedImage image;
/*    */   int width;
/*    */   int height;
/*    */   
/*    */   public Image grayscale(File input) {
/*    */     try {
/* 25 */       this.image = ImageIO.read(input);
/* 26 */       this.width = this.image.getWidth();
/* 27 */       this.height = this.image.getHeight();
/*    */       
/* 29 */       for (int i = 0; i < this.height; i++) {
/*    */         
/* 31 */         for (int j = 0; j < this.width; j++) {
/*    */           
/* 33 */           Color c = new Color(this.image.getRGB(j, i));
/* 34 */           int red = (int)(c.getRed() * 0.299D);
/* 35 */           int green = (int)(c.getGreen() * 0.587D);
/* 36 */           int blue = (int)(c.getBlue() * 0.114D);
/* 37 */           Color newColor = new Color(red + green + blue, red + green + blue, red + green + blue);
/* 38 */           this.image.setRGB(j, i, newColor.getRGB());
/*    */         } 
/*    */       } 
/*    */ 
/*    */       
/* 43 */       File ouptut = new File("Grayscale_" + input);
/* 44 */       ImageIO.write(this.image, "jpg", ouptut);
/*    */     }
/* 46 */     catch (Exception exception) {}
/*    */     
/* 48 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\GrayScale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */