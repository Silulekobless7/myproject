/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.DataBufferByte;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ import org.opencv.core.CvType;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GrayScale_2
/*    */ {
/*    */   BufferedImage image;
/*    */   int width;
/*    */   int height;
/*    */   
/*    */   public Image greyImage(BufferedImage image) throws IOException {
/* 36 */     byte[] data = ((DataBufferByte)image.getRaster().getDataBuffer()).getData();
/* 37 */     Mat mat = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
/* 38 */     mat.put(0, 0, data);
/*    */     
/* 40 */     Mat mat1 = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC1);
/* 41 */     Imgproc.cvtColor(mat, mat1, 7);
/*    */     
/* 43 */     byte[] data1 = new byte[mat1.rows() * mat1.cols() * (int)mat1.elemSize()];
/* 44 */     mat1.get(0, 0, data1);
/* 45 */     BufferedImage image1 = new BufferedImage(mat1.cols(), mat1.rows(), 10);
/* 46 */     image1.getRaster().setDataElements(0, 0, mat1.cols(), mat1.rows(), data1);
/*    */     
/* 48 */     File ouptut = new File("grayscale.jpg");
/* 49 */     ImageIO.write(image1, "jpg", ouptut);
/*    */ 
/*    */ 
/*    */     
/* 53 */     CreateBufferedImage x = new CreateBufferedImage();
/* 54 */     Image j = x.Mat2BufferedImage(mat1);
/*    */     
/* 56 */     return j;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\GrayScale_2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */