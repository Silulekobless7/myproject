/*     */ import java.awt.image.BufferedImage;
/*     */ import org.opencv.core.Core;
/*     */ import org.opencv.core.Mat;
/*     */ import org.opencv.core.Size;
/*     */ import org.opencv.highgui.Highgui;
/*     */ import org.opencv.imgproc.Imgproc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Morphology
/*     */ {
/*     */   String input;
/*  17 */   int erosion_size = 5;
/*  18 */   int dilation_size = 5;
/*     */   
/*     */   BufferedImage image;
/*     */ 
/*     */   
/*     */   public Morphology(String input) {
/*  24 */     this.input = input;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage erosion() {
/*     */     try {
/*  31 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  32 */       Mat source = Highgui.imread(this.input, 1);
/*  33 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  35 */       destination = source;
/*     */       
/*  37 */       Mat element = Imgproc.getStructuringElement(0, new Size((2 * this.erosion_size + 1), (2 * this.erosion_size + 1)));
/*  38 */       Imgproc.erode(source, destination, element);
/*  39 */       Highgui.imwrite("Erosion_" + this.input, destination);
/*     */       
/*  41 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  42 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  45 */     catch (Exception e) {
/*     */       
/*  47 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/*  50 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage dilation() {
/*     */     try {
/*  57 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  58 */       Mat source = Highgui.imread(this.input, 1);
/*  59 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  61 */       destination = source;
/*     */       
/*  63 */       Mat element = Imgproc.getStructuringElement(0, new Size((2 * this.dilation_size + 1), (2 * this.dilation_size + 1)));
/*  64 */       Imgproc.dilate(source, destination, element);
/*  65 */       Highgui.imwrite("Dilation_" + this.input, destination);
/*     */       
/*  67 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  68 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  71 */     catch (Exception e) {
/*     */       
/*  73 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/*  76 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage open() {
/*     */     try {
/*  83 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  84 */       Mat source = Highgui.imread(this.input, 1);
/*  85 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  87 */       destination = source;
/*     */       
/*  89 */       Mat element = Imgproc.getStructuringElement(0, new Size((2 * this.dilation_size + 1), (2 * this.dilation_size + 1)));
/*  90 */       Imgproc.morphologyEx(source, destination, 2, element);
/*  91 */       Highgui.imwrite("Open_" + this.input, destination);
/*     */       
/*  93 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  94 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  97 */     catch (Exception e) {
/*     */       
/*  99 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 102 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage close() {
/*     */     try {
/* 109 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 110 */       Mat source = Highgui.imread(this.input, 1);
/* 111 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/* 113 */       destination = source;
/*     */       
/* 115 */       Mat element = Imgproc.getStructuringElement(0, new Size((2 * this.dilation_size + 1), (2 * this.dilation_size + 1)));
/* 116 */       Imgproc.morphologyEx(source, destination, 3, element);
/* 117 */       Highgui.imwrite("Close_" + this.input, destination);
/*     */       
/* 119 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 120 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/* 123 */     catch (Exception e) {
/*     */       
/* 125 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 128 */     return this.image;
/*     */   }
/*     */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Morphology.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */