/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements ActionListener
/*     */ {
/*     */   public void actionPerformed(ActionEvent arg0) {
/*     */     BufferedImage threshImage;
/*     */     Image newImage;
/*     */     ImageIcon newIcon;
/* 311 */     int choice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1: Binary Thresholding\nEnter 2: Binary Invert Thresholding\nEnter 3: Zero Thresholding"));
/*     */     
/* 313 */     Thresholding t = new Thresholding(BankNotesRecognitionSystem.this.fileName);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     switch (choice) {
/*     */       case 1:
/* 320 */         threshImage = t.ThreshBinary();
/* 321 */         BankNotesRecognitionSystem.this.processedImage = threshImage;
/* 322 */         BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 323 */         BankNotesRecognitionSystem.this.processedFile = "BinaryThresh_" + BankNotesRecognitionSystem.this.fileName;
/*     */         
/* 325 */         newImage = threshImage.getScaledInstance(350, 150, 4);
/* 326 */         newIcon = new ImageIcon(newImage);
/* 327 */         lblProcessedImage.setIcon(newIcon);
/*     */         return;
/*     */       case 2:
/* 330 */         threshImage = t.ThreshBinaryInv();
/* 331 */         BankNotesRecognitionSystem.this.processedImage = threshImage;
/* 332 */         BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 333 */         BankNotesRecognitionSystem.this.processedFile = "BinaryInvThresh_" + BankNotesRecognitionSystem.this.fileName;
/*     */         
/* 335 */         newImage = threshImage.getScaledInstance(350, 150, 4);
/* 336 */         newIcon = new ImageIcon(newImage);
/* 337 */         lblProcessedImage.setIcon(newIcon);
/*     */         return;
/*     */       case 3:
/* 340 */         threshImage = t.ThreshToZero();
/* 341 */         BankNotesRecognitionSystem.this.processedImage = threshImage;
/* 342 */         BankNotesRecognitionSystem.this.image = BankNotesRecognitionSystem.this.processedImage;
/* 343 */         BankNotesRecognitionSystem.this.processedFile = "ZeroThresh_" + BankNotesRecognitionSystem.this.fileName;
/*     */         
/* 345 */         newImage = threshImage.getScaledInstance(350, 150, 4);
/* 346 */         newIcon = new ImageIcon(newImage);
/* 347 */         lblProcessedImage.setIcon(newIcon);
/*     */         return;
/*     */     } 
/*     */     
/* 351 */     System.out.println("Invalid Entry!");
/*     */   }
/*     */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\BankNotesRecognitionSystem$10.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */