/*    */ import java.awt.Color;
/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Negative
/*    */ {
/*    */   BufferedImage image;
/*    */   int width;
/*    */   int height;
/*    */   
/*    */   public Image negative(File input) {
/*    */     try {
/* 30 */       this.image = ImageIO.read(input);
/* 31 */       this.width = this.image.getWidth();
/* 32 */       this.height = this.image.getHeight();
/*    */       
/* 34 */       for (int i = 0; i < this.height; i++) {
/*    */         
/* 36 */         for (int j = 0; j < this.width; j++) {
/*    */           
/* 38 */           Color c = new Color(this.image.getRGB(j, i));
/* 39 */           int red = 255 - c.getRed();
/* 40 */           int green = 255 - c.getGreen();
/* 41 */           int blue = 255 - c.getBlue();
/* 42 */           Color newColor = new Color(red, green, blue);
/* 43 */           this.image.setRGB(j, i, newColor.getRGB());
/*    */         } 
/*    */       } 
/*    */ 
/*    */       
/* 48 */       File ouptut = new File("Grayscale_" + input);
/* 49 */       ImageIO.write(this.image, "jpg", ouptut);
/*    */     }
/* 51 */     catch (Exception exception) {}
/*    */     
/* 53 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Negative.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */