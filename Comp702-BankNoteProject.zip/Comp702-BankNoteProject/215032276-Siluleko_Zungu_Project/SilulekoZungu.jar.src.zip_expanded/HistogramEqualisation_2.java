/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.highgui.Highgui;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ 
/*    */ 
/*    */ public class HistogramEqualisation_2
/*    */ {
/*    */   static int width;
/*    */   static int height;
/* 11 */   static double alpha = 2.0D;
/* 12 */   static double beta = 50.0D;
/*    */   
/*    */   public Mat histogram(String t) {
/* 15 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 16 */     Mat source = Highgui.imread(t, 0);
/* 17 */     Mat destination = 
/* 18 */       new Mat(source.rows(), source.cols(), source.type());
/* 19 */     Imgproc.equalizeHist(source, destination);
/* 20 */     Highgui.imwrite("equalisation.jpg", destination);
/* 21 */     return destination;
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\HistogramEqualisation_2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */