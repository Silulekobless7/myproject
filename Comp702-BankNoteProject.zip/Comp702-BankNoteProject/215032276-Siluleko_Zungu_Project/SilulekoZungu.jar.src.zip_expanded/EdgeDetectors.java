/*     */ import java.awt.image.BufferedImage;
/*     */ import org.opencv.core.Core;
/*     */ import org.opencv.core.Mat;
/*     */ import org.opencv.highgui.Highgui;
/*     */ import org.opencv.imgproc.Imgproc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EdgeDetectors
/*     */ {
/*     */   String input;
/*     */   BufferedImage image;
/*     */   
/*     */   public EdgeDetectors(String input) {
/*  21 */     this.input = input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage Laplacian() {
/*     */     try {
/*  29 */       int kernalSize = 9;
/*     */       
/*  31 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  32 */       Mat source = Highgui.imread(this.input, 0);
/*  33 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  35 */       Mat kernal = new Mat(kernalSize, kernalSize, 5)
/*     */         {
/*     */         
/*     */         };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  50 */       Imgproc.filter2D(source, destination, -1, kernal);
/*  51 */       Highgui.imwrite("Laplacian_" + this.input, destination);
/*     */       
/*  53 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  54 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  57 */     catch (Exception e) {
/*     */       
/*  59 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/*  62 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage Prewitt() {
/*     */     try {
/*  70 */       int kernalSize = 9;
/*     */       
/*  72 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  73 */       Mat source = Highgui.imread(this.input, 0);
/*  74 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  76 */       Mat kernal = new Mat(kernalSize, kernalSize, 5)
/*     */         {
/*     */         
/*     */         };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       Imgproc.filter2D(source, destination, -1, kernal);
/*  92 */       Highgui.imwrite("Prewitt_" + this.input, destination);
/*     */       
/*  94 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  95 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  98 */     catch (Exception e) {
/*     */       
/* 100 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 103 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage Robinson() {
/*     */     try {
/* 111 */       int kernalSize = 9;
/*     */       
/* 113 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 114 */       Mat source = Highgui.imread(this.input, 0);
/* 115 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/* 117 */       Mat kernal = new Mat(kernalSize, kernalSize, 5)
/*     */         {
/*     */         
/*     */         };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       Imgproc.filter2D(source, destination, -1, kernal);
/* 133 */       Highgui.imwrite("Robinson_" + this.input, destination);
/*     */       
/* 135 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 136 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/* 139 */     catch (Exception e) {
/*     */       
/* 141 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 144 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage Sobel() {
/*     */     try {
/* 152 */       int kernalSize = 9;
/*     */       
/* 154 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 155 */       Mat source = Highgui.imread(this.input, 0);
/* 156 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/* 158 */       Mat kernal = new Mat(kernalSize, kernalSize, 5)
/*     */         {
/*     */         
/*     */         };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 173 */       Imgproc.filter2D(source, destination, -1, kernal);
/* 174 */       Highgui.imwrite("Sobel_" + this.input, destination);
/*     */       
/* 176 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 177 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/* 180 */     catch (Exception e) {
/*     */       
/* 182 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 185 */     return this.image;
/*     */   }
/*     */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\EdgeDetectors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */