/*     */ import java.awt.image.BufferedImage;
/*     */ import org.opencv.core.Core;
/*     */ import org.opencv.core.Mat;
/*     */ import org.opencv.core.Size;
/*     */ import org.opencv.highgui.Highgui;
/*     */ import org.opencv.imgproc.Imgproc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Filters
/*     */ {
/*     */   BufferedImage image;
/*     */   
/*     */   public BufferedImage gaussian(String input, int size) {
/*     */     try {
/*  25 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  26 */       Mat source = Highgui.imread(input, 1);
/*  27 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  29 */       Imgproc.GaussianBlur(source, destination, new Size(size, size), 0.0D);
/*  30 */       Highgui.imwrite("Gaussian_" + input, destination);
/*     */       
/*  32 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  33 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */ 
/*     */     
/*     */     }
/*  37 */     catch (Exception e) {
/*     */       
/*  39 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/*  42 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage WeightedAverage(String input) {
/*     */     try {
/*  49 */       int kernalSize = 9;
/*     */       
/*  51 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  52 */       Mat source = Highgui.imread(input, 0);
/*  53 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/*  55 */       Mat kernal = new Mat(kernalSize, kernalSize, 5);
/*     */       
/*  57 */       for (int i = 0; i < kernal.rows(); i++) {
/*     */         
/*  59 */         for (int j = 0; j < kernal.cols(); j++) {
/*     */           
/*  61 */           double[] m = kernal.get(i, j);
/*     */           
/*  63 */           for (int k = 0; k < m.length; k++) {
/*     */             
/*  65 */             if (i == 1 && j == 1) {
/*  66 */               m[k] = 0.0D;
/*     */             } else {
/*     */               
/*  69 */               m[k] = m[k] / 18.0D;
/*     */             } 
/*     */           } 
/*  72 */           kernal.put(i, j, m);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  78 */       Imgproc.filter2D(source, destination, -1, kernal);
/*  79 */       Highgui.imwrite("WeightedAverage_" + input, destination);
/*     */       
/*  81 */       CreateBufferedImage cbi = new CreateBufferedImage();
/*  82 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */     
/*     */     }
/*  85 */     catch (Exception e) {
/*     */       
/*  87 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/*  90 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage median(String input, int size) {
/*     */     try {
/*  97 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/*  98 */       Mat source = Highgui.imread(input, 1);
/*  99 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/* 101 */       Imgproc.medianBlur(source, destination, size);
/* 102 */       Highgui.imwrite("Median_" + input, destination);
/*     */       
/* 104 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 105 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */ 
/*     */     
/*     */     }
/* 109 */     catch (Exception e) {
/*     */       
/* 111 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 114 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage bilateral(String input, int d, double sigmaColor, double sigmaSpace) {
/*     */     try {
/* 121 */       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 122 */       Mat source = Highgui.imread(input, 1);
/* 123 */       Mat destination = new Mat(source.rows(), source.cols(), source.type());
/*     */       
/* 125 */       Imgproc.bilateralFilter(source, destination, d, sigmaColor, sigmaSpace);
/* 126 */       Highgui.imwrite("Bilateral_" + input, destination);
/*     */       
/* 128 */       CreateBufferedImage cbi = new CreateBufferedImage();
/* 129 */       this.image = cbi.Mat2BufferedImage(destination);
/*     */ 
/*     */     
/*     */     }
/* 133 */     catch (Exception e) {
/*     */       
/* 135 */       System.out.println("Error : " + e.getMessage());
/*     */     } 
/*     */     
/* 138 */     return this.image;
/*     */   }
/*     */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\Filters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */