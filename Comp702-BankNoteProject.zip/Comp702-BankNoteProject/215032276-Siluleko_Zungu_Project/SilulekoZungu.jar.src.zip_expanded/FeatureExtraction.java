/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import javax.imageio.ImageIO;
/*    */ import org.opencv.core.Core;
/*    */ import org.opencv.core.Mat;
/*    */ import org.opencv.core.MatOfPoint;
/*    */ import org.opencv.highgui.Highgui;
/*    */ import org.opencv.imgproc.Imgproc;
/*    */ import org.opencv.imgproc.Moments;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeatureExtraction
/*    */ {
/*    */   public static void HusMoments(Mat image) {
/* 27 */     ArrayList<MatOfPoint> contours = new ArrayList<>();
/* 28 */     Imgproc.findContours(image, contours, new Mat(), 1, 2);
/* 29 */     Moments mom = new Moments();
/* 30 */     mom = Imgproc.moments((Mat)contours.get(0), false);
/* 31 */     Mat hu = new Mat();
/* 32 */     Imgproc.HuMoments(mom, hu);
/*    */     
/* 34 */     int r = hu.height();
/* 35 */     int c = hu.width();
/*    */     
/* 37 */     for (int i = 0; i < r; i++) {
/*    */       
/* 39 */       for (int j = 0; j < c; j++)
/*    */       {
/* 41 */         System.out.print(hu.size());
/*    */       }
/* 43 */       System.out.println();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 50 */     File file = new File("fett.jpg");
/* 51 */     BufferedImage image = null;
/*    */     
/*    */     try {
/* 54 */       image = ImageIO.read(file);
/*    */     
/*    */     }
/* 57 */     catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 62 */     System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
/* 63 */     Mat m = Highgui.imread("fett.jpg", 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\Student\Downloads\BankNotesRecognition-master\BankNotesRecognition-master\datafileX\datafileX\dataX\AveshniReddy.jar!\FeatureExtraction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */